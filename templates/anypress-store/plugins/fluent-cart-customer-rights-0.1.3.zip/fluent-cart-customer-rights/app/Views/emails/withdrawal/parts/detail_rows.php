<?php if (!defined('ABSPATH')) exit;

/**
 * Withdrawal detail table.
 *
 * @var bool $include_message Whether the part/note row applies (partial revocations permitted)
 */

$cellLabel = 'padding:6px 12px 6px 0;color:#565865;white-space:nowrap;vertical-align:top;';
$cellValue = 'padding:6px 0;color:#2F3448;font-weight:500;';
?>
<table style="border-collapse:collapse;margin:14px 0;font-size:14px;">
    <tr>
        <td style="<?php echo esc_attr($cellLabel); ?>"><?php echo esc_html__('Received on', 'fluent-cart-customer-rights'); ?></td>
        <td style="<?php echo esc_attr($cellValue); ?>">{{withdrawal.received_at}}</td>
    </tr>
    <tr>
        <td style="<?php echo esc_attr($cellLabel); ?>"><?php echo esc_html__('Name', 'fluent-cart-customer-rights'); ?></td>
        <td style="<?php echo esc_attr($cellValue); ?>">{{withdrawal.name}}</td>
    </tr>
    <tr>
        <td style="<?php echo esc_attr($cellLabel); ?>"><?php echo esc_html__('Order number', 'fluent-cart-customer-rights'); ?></td>
        <td style="<?php echo esc_attr($cellValue); ?>">{{withdrawal.order_reference}}</td>
    </tr>
    <?php if (!empty($include_message)): ?>
        <tr>
            <td style="<?php echo esc_attr($cellLabel); ?>"><?php echo esc_html__('Part / note', 'fluent-cart-customer-rights'); ?></td>
            <td style="<?php echo esc_attr($cellValue); ?>">{{withdrawal.message}}</td>
        </tr>
    <?php endif; ?>
    <tr>
        <td style="<?php echo esc_attr($cellLabel); ?>"><?php echo esc_html__('Reference', 'fluent-cart-customer-rights'); ?></td>
        <td style="<?php echo esc_attr($cellValue); ?>">{{withdrawal.reference}}</td>
    </tr>
</table>
