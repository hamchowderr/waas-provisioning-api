<?php if (!defined('ABSPATH')) exit;

/**
 * Statutory acknowledgment of receipt to the customer (§ 356a BGB).
 *
 * Smartcodes are resolved by core's parser after this renders — see the
 * withdrawal.* resolver in FluentCartCustomerRights\Emails.
 */

$include_message = \FluentCartCustomerRights\Settings::getPartialRevocationsPermitted();
?>
<h2 style="margin:0 0 16px;"><?php echo esc_html__('We have received your withdrawal request', 'fluent-cart-customer-rights'); ?></h2>

<p><?php echo esc_html__('Hello {{withdrawal.name}},', 'fluent-cart-customer-rights'); ?></p>

<p><?php echo esc_html__('this acknowledgment confirms receipt of your withdrawal request with the following content:', 'fluent-cart-customer-rights'); ?></p>

<?php include __DIR__ . '/parts/detail_rows.php'; ?>

<p><?php echo esc_html__('This confirms receipt of your declaration. We will review your request and contact you about the next steps.', 'fluent-cart-customer-rights'); ?></p>

<p>{{settings.store_name}}</p>
