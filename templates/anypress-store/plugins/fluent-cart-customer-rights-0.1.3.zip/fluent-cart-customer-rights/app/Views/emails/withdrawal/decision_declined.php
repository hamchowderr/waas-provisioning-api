<?php if (!defined('ABSPATH')) exit;

/**
 * Notice to the customer that the store declined their withdrawal request.
 */

$include_message = \FluentCartCustomerRights\Settings::getPartialRevocationsPermitted();
?>
<p><?php echo esc_html__('Hello {{withdrawal.name}},', 'fluent-cart-customer-rights'); ?></p>

<p><?php echo esc_html__('After reviewing your withdrawal request we are unable to accept it. Reply to this email if you have questions or believe this is a mistake.', 'fluent-cart-customer-rights'); ?></p>

<?php include __DIR__ . '/parts/detail_rows.php'; ?>

<p>{{settings.store_name}}</p>
