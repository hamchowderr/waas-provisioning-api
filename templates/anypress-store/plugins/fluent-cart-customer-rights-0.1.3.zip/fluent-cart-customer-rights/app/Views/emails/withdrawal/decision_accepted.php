<?php if (!defined('ABSPATH')) exit;

/**
 * Notice to the customer that the store accepted their withdrawal request.
 */

$include_message = \FluentCartCustomerRights\Settings::getPartialRevocationsPermitted();
?>
<p><?php echo esc_html__('Hello {{withdrawal.name}},', 'fluent-cart-customer-rights'); ?></p>

<p><?php echo esc_html__('Good news — we have accepted your withdrawal request. We will contact you about the refund and the next steps if anything is needed from your side.', 'fluent-cart-customer-rights'); ?></p>

<?php include __DIR__ . '/parts/detail_rows.php'; ?>

<p>{{settings.store_name}}</p>
