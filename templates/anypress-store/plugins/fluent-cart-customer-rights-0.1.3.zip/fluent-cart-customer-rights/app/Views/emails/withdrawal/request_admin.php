<?php if (!defined('ABSPATH')) exit;

/**
 * New withdrawal declaration notice to the store admin.
 */

$include_message = \FluentCartCustomerRights\Settings::getPartialRevocationsPermitted();
?>
<h2 style="margin:0 0 16px;"><?php echo esc_html__('New withdrawal request', 'fluent-cart-customer-rights'); ?></h2>

<p><?php echo esc_html__('A customer has submitted a withdrawal declaration — identification: {{withdrawal.verified}}', 'fluent-cart-customer-rights'); ?></p>

<?php include __DIR__ . '/parts/detail_rows.php'; ?>

{{withdrawal.excluded_items_note}}

<p><?php echo esc_html__('Please review it without undue delay in your FluentCart admin.', 'fluent-cart-customer-rights'); ?></p>
