<?php

namespace FluentCartCustomerRights;

defined('ABSPATH') or die;

class Emails
{
    /**
     * Smartcodes this add-on resolves for core's parser. Keyed without the
     * braces — the parser hands over the bare code.
     */
    const SMARTCODE_PREFIX = 'withdrawal.';

    public function register()
    {
        // Registry entries appear in core's Email Notifications UI and the
        // `wp fluent_cart test_email` CLI like native notifications.
        add_filter('fluent_cart/email_notifications', [$this, 'registerNotifications']);

        // Templates live in this plugin, outside core's views directory.
        add_filter('fluent_cart/email/template_view_path', [$this, 'resolveTemplatePath'], 10, 2);

        // {{withdrawal.*}} is ours; core's parser delegates unknown codes here.
        add_filter('fluent_cart/smartcode_fallback', [$this, 'resolveSmartcode'], 10, 2);

        // Withdrawal declarations are time-sensitive legal documents that may
        // need to reach a different person than the general store admin.
        add_filter('fluent_cart/admin_email/notification_recipient', [$this, 'overrideAdminRecipient'], 10, 2);

        // Dispatch stays here rather than on core's event listeners: the
        // statutory acknowledgment must send even when toggled off, and the
        // decision notices key off a status transition rather than an event.
        add_action('fluent_cart/withdrawal_requested', [$this, 'onRequested']);
        add_action('fluent_cart/withdrawal_request_status_updated', [$this, 'onStatusUpdated']);
    }

    public function registerNotifications($notifications)
    {
        if (!is_array($notifications)) {
            $notifications = [];
        }

        $groupLabel = __('Withdrawal', 'fluent-cart-customer-rights');

        $base = [
            'group'            => 'withdrawal',
            'group_label'      => $groupLabel,
            'smartcode_groups' => [],
            'is_async'         => false,
        ];

        // Every one of these is addressed to whoever filed the declaration, not
        // to an order's customer — an unverified request may match no order at
        // all, and even a matched one can carry a different address. Declaring
        // `to` keeps core off the {{order.customer.email}} path entirely.
        $customerBase = array_merge($base, [
            'recipient' => 'customer',
            'to'        => '{{withdrawal.email}}',
        ]);

        $notifications['withdrawal_request_customer'] = array_merge($customerBase, [
            'event'         => 'withdrawal_requested',
            'title'         => __('Withdrawal acknowledgment to customer', 'fluent-cart-customer-rights'),
            'description'   => __('Acknowledgment of receipt with the date and time of the withdrawal declaration. Required by § 356a BGB — it is sent whenever the withdrawal module is enabled, even if toggled off here.', 'fluent-cart-customer-rights'),
            'template_path' => 'fctcr:withdrawal.request_customer',
            'settings'      => [
                'active'              => 'yes',
                'subject'             => __('We received your withdrawal request — {{withdrawal.reference}}', 'fluent-cart-customer-rights'),
                'is_default_body'     => 'yes',
                'email_body'          => '',
                'attach_pdf_template' => '',
            ],
        ]);

        $notifications['withdrawal_request_admin'] = array_merge($base, [
            'event'         => 'withdrawal_requested',
            'title'         => __('New withdrawal request to admin', 'fluent-cart-customer-rights'),
            'description'   => __('Notifies the store admin when a customer submits a withdrawal declaration.', 'fluent-cart-customer-rights'),
            'recipient'     => 'admin',
            'template_path' => 'fctcr:withdrawal.request_admin',
            'settings'      => [
                'active'              => 'yes',
                'subject'             => __('New withdrawal request on {{settings.store_name}}', 'fluent-cart-customer-rights'),
                'is_default_body'     => 'yes',
                'email_body'          => '',
                'attach_pdf_template' => '',
            ],
        ]);

        $notifications['withdrawal_accepted_customer'] = array_merge($customerBase, [
            'event'         => 'withdrawal_accepted',
            'title'         => __('Withdrawal accepted notice to customer', 'fluent-cart-customer-rights'),
            'description'   => __('Sent automatically when the store accepts a withdrawal request.', 'fluent-cart-customer-rights'),
            'template_path' => 'fctcr:withdrawal.decision_accepted',
            'settings'      => [
                'active'              => 'yes',
                'subject'             => __('Your withdrawal request has been accepted — {{withdrawal.reference}}', 'fluent-cart-customer-rights'),
                'is_default_body'     => 'yes',
                'email_body'          => '',
                'attach_pdf_template' => '',
            ],
        ]);

        $notifications['withdrawal_declined_customer'] = array_merge($customerBase, [
            'event'         => 'withdrawal_declined',
            'title'         => __('Withdrawal declined notice to customer', 'fluent-cart-customer-rights'),
            'description'   => __('Sent automatically when the store declines a withdrawal request.', 'fluent-cart-customer-rights'),
            'template_path' => 'fctcr:withdrawal.decision_declined',
            'settings'      => [
                'active'              => 'yes',
                'subject'             => __('About your withdrawal request — {{withdrawal.reference}}', 'fluent-cart-customer-rights'),
                'is_default_body'     => 'yes',
                'email_body'          => '',
                'attach_pdf_template' => '',
            ],
        ]);

        return $notifications;
    }

    /**
     * Map our "fctcr:" template paths onto real files in this plugin.
     *
     * An absolute path is returned rather than the framework's
     * "plugin-slug:path" namespace: View::make() resolves an existing file
     * before anything else, whereas loadViewFrom() dot-replaces the whole
     * resolved string and would break on a plugin directory containing a dot.
     *
     * @param string $viewPath
     * @param array $context
     * @return string
     */
    public function resolveTemplatePath($viewPath, $context)
    {
        $templatePath = isset($context['template_path']) ? (string)$context['template_path'] : '';

        if (strpos($templatePath, 'fctcr:') !== 0) {
            return $viewPath;
        }

        $relative = str_replace('.', '/', substr($templatePath, strlen('fctcr:')));

        $file = FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Views/emails/' . $relative;

        return file_exists($file . '.php') ? $file : $viewPath;
    }

    /**
     * @param array $payload ['request' => row, 'order' => Order|null]
     */
    public function onRequested($payload)
    {
        $request = isset($payload['request']) ? $payload['request'] : null;
        if (!$request) {
            return;
        }

        // The acknowledgment is statutory: forced while the module is enabled,
        // the stored active flag is intentionally ignored.
        $this->sendNotification('withdrawal_request_customer', $request, isset($payload['order']) ? $payload['order'] : null, true);
        $this->sendNotification('withdrawal_request_admin', $request, isset($payload['order']) ? $payload['order'] : null, false);
    }

    /**
     * @param array $payload ['request' => row, 'old_status' => string, 'new_status' => string, 'actor_id' => int]
     */
    public function onStatusUpdated($payload)
    {
        $request = isset($payload['request']) ? $payload['request'] : null;
        $newStatus = isset($payload['new_status']) ? $payload['new_status'] : '';

        if (!$request || !in_array($newStatus, ['accepted', 'declined'], true)) {
            return;
        }

        $name = $newStatus === 'accepted' ? 'withdrawal_accepted_customer' : 'withdrawal_declined_customer';
        $this->sendNotification($name, $request, null, false);
    }

    private function sendNotification($name, $request, $order, $forced)
    {
        if (!Settings::isEnabled()) {
            return;
        }

        if (!class_exists('\FluentCart\App\Services\Email\EmailNotificationMailer')) {
            return;
        }

        // Merged config: defaults from the filter + any admin customization.
        $notification = \FluentCart\App\Services\Email\EmailNotifications::getNotification($name);
        if (!$notification) {
            return;
        }

        $settings = isset($notification['settings']) ? $notification['settings'] : [];

        // mailByEmailName() does not consult `active` — the check stays here so
        // the statutory acknowledgment can bypass it while the rest honour it.
        if (!$forced && (!isset($settings['active']) || $settings['active'] !== 'yes')) {
            return;
        }

        // Everything the templates, subject and recipient need. `withdrawal`
        // backs the {{withdrawal.*}} codes; `order` stays a real model or null
        // so core renders (or skips) its order header correctly.
        $data = [
            'order'      => $order,
            'withdrawal' => [
                'request' => $request,
                'order'   => $order,
            ],
        ];

        (new \FluentCart\App\Services\Email\EmailNotificationMailer())->mailByEmailName($name, $data);
    }

    /**
     * Route admin-bound withdrawal mail to the module's own address.
     *
     * Withdrawal declarations are time-sensitive legal documents that may need
     * to reach a different person than the general store admin.
     *
     * @param string $to
     * @param array $context
     * @return string
     */
    public function overrideAdminRecipient($to, $context)
    {
        $mailName = isset($context['mail_name']) ? $context['mail_name'] : '';

        if (strpos($mailName, 'withdrawal_') !== 0) {
            return $to;
        }

        $override = Settings::getAdminNotificationEmail();

        return $override ? sanitize_email($override) : $to;
    }

    /**
     * Resolve {{withdrawal.*}} for core's smartcode parser.
     *
     * Core hands over any code it has no handler for, so anything outside our
     * prefix is returned untouched for the next listener.
     *
     * @param string $code bare code, e.g. "withdrawal.email"
     * @param array $data view data passed to the mailer
     * @return string
     */
    public function resolveSmartcode($code, $data)
    {
        if (strpos($code, self::SMARTCODE_PREFIX) !== 0) {
            return $code;
        }

        $request = isset($data['withdrawal']['request']) ? $data['withdrawal']['request'] : null;
        if (!$request) {
            return '';
        }

        $order = isset($data['withdrawal']['order']) ? $data['withdrawal']['order'] : null;

        $values = $this->smartcodeValues($request, $order);

        $key = substr($code, strlen(self::SMARTCODE_PREFIX));

        return isset($values[$key]) ? $values[$key] : '';
    }

    /**
     * @return array<string, string> keyed without the "withdrawal." prefix
     */
    private function smartcodeValues($request, $order)
    {
        $receivedAt = get_date_from_gmt(
            $request->submitted_at,
            get_option('date_format') . ' ' . get_option('time_format')
        );

        return [
            'name'                => esc_html($request->name),
            // The recipient smartcode — must stay a bare address, not escaped
            // markup, because it is handed straight to wp_mail().
            'email'               => sanitize_email($request->email),
            'order_reference'     => esc_html($request->order_reference),
            'message'             => $request->message !== '' && $request->message !== null
                ? esc_html($request->message)
                : esc_html__('Entire contract', 'fluent-cart-customer-rights'),
            'reference'           => strtoupper(substr($request->uuid, 0, 8)),
            'received_at'         => esc_html($receivedAt),
            'verified'            => $request->is_verified
                ? esc_html__('matched to an order', 'fluent-cart-customer-rights')
                : esc_html__('not matched — needs manual review', 'fluent-cart-customer-rights'),
            'excluded_items_note' => $this->buildExcludedItemsNote($request),
            'invoice_no'          => $order && !empty($order->invoice_no)
                ? esc_html($order->invoice_no)
                : esc_html($request->order_reference),
        ];
    }

    private function buildExcludedItemsNote($request)
    {
        $meta = ($request->meta && is_string($request->meta)) ? json_decode($request->meta, true) : [];
        if (!is_array($meta) || empty($meta['excluded_items']) || !is_array($meta['excluded_items'])) {
            return '';
        }

        $allExcluded = !empty($meta['all_excluded']);
        $itemsList   = implode(', ', array_map('esc_html', $meta['excluded_items']));
        $badge       = $allExcluded
            ? esc_html__('All items excluded', 'fluent-cart-customer-rights')
            : esc_html__('Partial exclusion', 'fluent-cart-customer-rights');
        $note        = $allExcluded
            ? esc_html__('No items in this order are eligible for withdrawal — partial handling required.', 'fluent-cart-customer-rights')
            : esc_html__('Some items in this order are not eligible for withdrawal — partial handling may be required.', 'fluent-cart-customer-rights');

        return '<div style="background:#FFF9F3;border:1px solid #FDE8CD;border-radius:6px;padding:12px 16px;margin:14px 0;">'
            . '<strong style="color:#AC6305;">' . $badge . ':</strong> '
            . '<span style="color:#2F3448;">' . $itemsList . '</span><br>'
            . '<em style="color:#AC6305;font-size:13px;">' . $note . '</em>'
            . '</div>';
    }
}
