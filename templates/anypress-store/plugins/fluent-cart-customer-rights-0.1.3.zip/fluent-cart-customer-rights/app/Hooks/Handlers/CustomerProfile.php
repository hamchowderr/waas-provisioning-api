<?php

namespace FluentCartCustomerRights;

defined('ABSPATH') or die;

class CustomerProfile
{
    public function register()
    {
        add_filter('fluent_cart/customer/subscription_details_section_parts', [$this, 'addSubscriptionFooter'], 10, 2);
        add_filter('fluent_cart/customer/order_details_section_parts',        [$this, 'addOrderFooter'],        10, 2);
        add_filter('fluent_cart/customer_dashboard_data',                     [$this, 'addDashboardFooter'],    10, 2);
    }

    // -------------------------------------------------------------------------
    // Subscription detail footer (section_parts → end_of_subscription — SingleSubscription.vue)
    // -------------------------------------------------------------------------

    public function addSubscriptionFooter($sectionParts, $context)
    {
        if (!Settings::isEnabled() || Settings::get('show_in_subscription') !== 'yes') {
            return $sectionParts;
        }

        $pageUrl = Settings::getPageUrl();
        if (!$pageUrl) {
            return $sectionParts;
        }

        $subscription = isset($context['subscription']) ? $context['subscription'] : null;
        if (!$subscription) {
            return $sectionParts;
        }

        $orderId = isset($subscription->parent_order_id) ? (int)$subscription->parent_order_id : 0;

        $args        = ['subscription' => $subscription->uuid];
        $orderStatus    = '';
        $shippingStatus = '';
        if ($orderId && class_exists('\FluentCart\App\Models\Order')) {
            $order = \FluentCart\App\Models\Order::find($orderId);
            if ($order) {
                if (!empty($order->invoice_no)) {
                    $args['order'] = $order->invoice_no;
                }
                $orderStatus    = (string)($order->status ?? '');
                $shippingStatus = (string)($order->shipping_status ?? '');
            }
        }
        $activeUrl = add_query_arg($args, $pageUrl);

        $parts = $this->buildWithdrawalParts('subscription', $orderId, $activeUrl, $context, $orderStatus, $shippingStatus, $order ?? null);

        $html = Renderer::renderFooterParts($parts, 'subscription');
        if ($html) {
            $sectionParts['end_of_subscription'] .= $html;
        }

        return $sectionParts;
    }

    // -------------------------------------------------------------------------
    // Order detail footer (section_parts → end_of_order — rendered by SingleOrder.vue)
    // -------------------------------------------------------------------------

    public function addOrderFooter($sectionParts, $context)
    {
        if (!Settings::isEnabled() || Settings::get('show_in_order') !== 'yes') {
            return $sectionParts;
        }

        $pageUrl = Settings::getPageUrl();
        if (!$pageUrl) {
            return $sectionParts;
        }

        $order = isset($context['order']) ? $context['order'] : null;
        if (!$order) {
            return $sectionParts;
        }

        $orderId        = (int)$order->id;
        $invoiceNo      = !empty($order->invoice_no) ? $order->invoice_no : '';
        $activeUrl      = $invoiceNo ? add_query_arg(['order' => $invoiceNo], $pageUrl) : $pageUrl;
        $orderStatus    = (string)($order->status ?? '');
        $shippingStatus = (string)($order->shipping_status ?? '');

        $parts = $this->buildWithdrawalParts('order', $orderId, $activeUrl, $context, $orderStatus, $shippingStatus, $order);

        $html = Renderer::renderFooterParts($parts, 'order');
        if ($html) {
            $sectionParts['end_of_order'] .= $html;
        }

        return $sectionParts;
    }

    // -------------------------------------------------------------------------
    // Customer dashboard footer (section_parts → after_orders_table — Dashboard.vue)
    //
    // Note: core has a key-name mismatch — PHP returns 'sections_parts' but Vue
    // reads 'section_parts'. We write to both so it works once core fixes it.
    // -------------------------------------------------------------------------

    public function addDashboardFooter($response, $context)
    {
        if (!is_array($response)) {
            return $response;
        }

        if (!Settings::isEnabled() || Settings::get('show_in_dashboard') !== 'yes') {
            return $response;
        }

        $pageUrl = Settings::getPageUrl();
        if (!$pageUrl) {
            return $response;
        }

        // Dashboard has no per-order context, so orderId = 0 → no state check.
        $parts = $this->buildWithdrawalParts('dashboard', 0, $pageUrl, $context);

        $html = Renderer::renderFooterParts($parts, 'dashboard');
        if (!$html) {
            return $response;
        }

        foreach (['sections_parts', 'section_parts'] as $key) {
            if (!isset($response[$key]) || !is_array($response[$key])) {
                $response[$key] = ['before_orders_table' => '', 'after_orders_table' => ''];
            }
            $response[$key]['after_orders_table'] .= $html;
        }

        return $response;
    }

    // -------------------------------------------------------------------------
    // Shared helper
    // -------------------------------------------------------------------------

    /**
     * Resolves the withdrawal state for the given order and fires
     * `fctcr/customer/{location}_footer_parts` so third parties can add, remove,
     * or modify items before rendering.
     *
     * Returned items: ['key'=>string, 'state'=>'active|pending|accepted', 'url'=>string, 'label'=>string]
     *
     * @param string $location   'subscription' | 'order' | 'dashboard'
     * @param int    $orderId    0 when no order context is available (dashboard)
     * @param string $activeUrl  Pre-built URL with prefill args for the active state
     * @param array  $context    Raw FluentCart filter context passed through to the filter
     */
    /**
     * @param string     $orderStatus  The order's current status slug — used to suppress
     *                                 the active link when the status is admin-blocked.
     *                                 Already-submitted requests (pending/accepted) are
     *                                 shown regardless of status.
     * @param object|null $order       Full order object when available; used to suppress
     *                                 the active link when every item is Art. 16 CRD-excluded.
     */
    private function buildWithdrawalParts(string $location, int $orderId, string $activeUrl, array $context, string $orderStatus = '', string $shippingStatus = '', $order = null): array
    {
        $model = new RequestModel();

        if ($orderId && $model->getOpenByOrderId($orderId)) {
            $parts = [[
                'key'   => 'withdrawal',
                'state' => 'pending',
                'url'   => '',
                'label' => __('Withdrawal requested — pending review', 'fluent-cart-customer-rights'),
            ]];
        } elseif ($orderId && ($history = $model->getByOrderId($orderId)) && !empty($history[0])) {
            if ($history[0]->status === 'accepted') {
                $parts = [[
                    'key'   => 'withdrawal',
                    'state' => 'accepted',
                    'url'   => '',
                    'label' => __('Withdrawal accepted for this order', 'fluent-cart-customer-rights'),
                ]];
            } else {
                $parts = [[
                    'key'   => 'withdrawal',
                    'state' => 'declined',
                    'url'   => '',
                    'label' => __('Withdrawal declaration was not accepted', 'fluent-cart-customer-rights'),
                ]];
            }
        } else {
            // Hide the active link when the order status or shipping status is admin-blocked.
            $blocked = ($orderStatus && in_array($orderStatus, Settings::getBlockedOrderStatuses(), true))
                || ($shippingStatus && in_array($shippingStatus, Settings::getBlockedShippingStatuses(), true));

            // Hide when every item in the order is excluded from withdrawal (Art. 16 CRD).
            if (!$blocked && $order) {
                $service = new WithdrawalService();
                $exclusionResult = $service->checkExclusionsPublic($order);
                if ($exclusionResult['all_excluded']) {
                    $blocked = true;
                }
            }

            $parts = $blocked ? [] : [[
                'key'   => 'withdrawal',
                'state' => 'active',
                'url'   => $activeUrl,
                // Statutory label — § 356a BGB / Art. 11a CRD
                'label' => __('Withdraw from contract here', 'fluent-cart-customer-rights'),
            ]];
        }

        return (array) apply_filters("fctcr/customer/{$location}_footer_parts", $parts, $context);
    }
}
