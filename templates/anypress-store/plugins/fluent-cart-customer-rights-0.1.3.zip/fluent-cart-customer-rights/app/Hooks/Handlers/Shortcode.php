<?php

namespace FluentCartCustomerRights;

defined('ABSPATH') or die;

class Shortcode
{
    const SHORTCODE = 'fluent_cart_withdrawal';

    public static function register()
    {
        add_shortcode(self::SHORTCODE, [new static(), 'render']);
    }

    public function render($attrs = [], $content = '')
    {
        if (!Settings::isEnabled()) {
            return '';
        }

        $this->enqueueAssets();

        // Prefill: deep links carry ?order= / ?subscription=; logged-in
        // customers get name/email prefilled (§ 356a expressly allows it).
        $prefillOrder     = isset($_GET['order']) ? sanitize_text_field(wp_unslash($_GET['order'])) : '';
        $fromProfile      = !empty($_GET['subscription']);
        $prefillFirstName = '';
        $prefillLastName  = '';
        $prefillEmail     = '';

        if (is_user_logged_in()) {
            $user             = wp_get_current_user();
            $prefillFirstName = $user->first_name;
            $prefillLastName  = $user->last_name;
            if ($prefillFirstName === '' && $prefillLastName === '') {
                $prefillFirstName = $user->display_name;
            }
            $prefillEmail = $user->user_email;
        }

        // Deep links identify the order deterministically — surface the latest
        // existing request: a pending one blocks a duplicate declaration, a
        // decided one shows its status above the form.
        $statusPanel = '';
        $contextOrder = $this->resolveContextOrder($prefillOrder);
        if ($contextOrder) {
            $requests = (new RequestModel())->getByOrderId($contextOrder->id);
            $latest = $requests ? $requests[0] : null;

            if ($latest) {
                $statusPanel = $this->existingRequestPanel($latest);
                return '<div class="fctcr-wrap">' . $statusPanel . '</div>';
            }
        }

        $requiredFields     = Settings::getRequiredFields();
        $showComment        = Settings::getShowCommentField() && Settings::getPartialRevocationsPermitted();
        $isRequired         = static function (string $field) use ($requiredFields): bool {
            return in_array($field, $requiredFields, true);
        };

        ob_start();
        ?>
        <div class="fctcr-wrap" data-fctcr>

            <?php echo $statusPanel; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts ?>

            <!-- Step 1: the statutory three fields -->
            <section data-fctcr-step="form">
                <p class="fctcr-intro"><?php esc_html_e('You can revoke your contract here. Enter your details, review them on the next step, and confirm. You will receive an acknowledgment by email containing the date and time of your withdrawal.', 'fluent-cart-customer-rights'); ?></p>

                <form data-fctcr-form novalidate>
                    <div class="fctcr-field-row">
                        <div class="fctcr-field" data-field="first_name">
                            <label for="fctcr-first-name"><?php esc_html_e('First name', 'fluent-cart-customer-rights'); ?><?php if ($isRequired('first_name')): ?> <span class="fctcr-req">*</span><?php endif; ?></label>
                            <input type="text" id="fctcr-first-name" name="first_name" maxlength="190" value="<?php echo esc_attr($prefillFirstName); ?>" autocomplete="given-name">
                            <div class="fctcr-err" role="alert"></div>
                        </div>
                        <div class="fctcr-field" data-field="last_name">
                            <label for="fctcr-last-name"><?php esc_html_e('Last name', 'fluent-cart-customer-rights'); ?><?php if ($isRequired('last_name')): ?> <span class="fctcr-req">*</span><?php endif; ?></label>
                            <input type="text" id="fctcr-last-name" name="last_name" maxlength="190" value="<?php echo esc_attr($prefillLastName); ?>" autocomplete="family-name">
                            <div class="fctcr-err" role="alert"></div>
                        </div>
                    </div>

                    <div class="fctcr-field" data-field="order_number">
                        <label for="fctcr-order"><?php esc_html_e('Receipt number', 'fluent-cart-customer-rights'); ?><?php if ($isRequired('order_number')): ?> <span class="fctcr-req">*</span><?php endif; ?></label>
                        <input type="text" id="fctcr-order" name="order_number" maxlength="190" value="<?php echo esc_attr($prefillOrder); ?>">
                        <div class="fctcr-err" role="alert"></div>
                        <div class="fctcr-hint"><?php esc_html_e('You can find it on your order confirmation email or receipt.', 'fluent-cart-customer-rights'); ?></div>
                    </div>

                    <div class="fctcr-field" data-field="email">
                        <label for="fctcr-email"><?php esc_html_e('Email address', 'fluent-cart-customer-rights'); ?><?php if ($isRequired('email')): ?> <span class="fctcr-req">*</span><?php endif; ?></label>
                        <input type="email" id="fctcr-email" name="email" maxlength="190" value="<?php echo esc_attr($prefillEmail); ?>" autocomplete="email">
                        <div class="fctcr-err" role="alert"></div>
                        <div class="fctcr-hint"><?php esc_html_e('We will send the acknowledgment of receipt to this address.', 'fluent-cart-customer-rights'); ?></div>
                    </div>

                    <?php if ($showComment): ?>
                    <div class="fctcr-field" data-field="message">
                        <label for="fctcr-message"><?php esc_html_e('Additional note', 'fluent-cart-customer-rights'); ?> <span class="fctcr-opt"><?php esc_html_e('(optional)', 'fluent-cart-customer-rights'); ?></span></label>
                        <textarea id="fctcr-message" name="message" maxlength="2000"></textarea>
                        <div class="fctcr-hint"><?php esc_html_e('No reason is required — use this only if you want to add a note to your declaration.', 'fluent-cart-customer-rights'); ?></div>
                    </div>
                    <?php endif; ?>

                    <input type="text" name="fctcr_website" class="fctcr-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
                    <input type="hidden" name="source" value="<?php echo esc_attr($fromProfile ? 'customer_profile' : 'public_form'); ?>">

                    <div class="fctcr-global-err" data-fctcr-global-error role="alert" hidden></div>

                    <button type="submit" class="fctcr-btn-primary" data-fctcr-continue><?php esc_html_e('Continue', 'fluent-cart-customer-rights'); ?></button>
                </form>
            </section>

            <!-- Step 1b: item + subscription selection (logged-in owner only) -->
            <section data-fctcr-step="items" hidden>
                <h3 class="fctcr-step-title"><?php esc_html_e('What would you like to withdraw?', 'fluent-cart-customer-rights'); ?></h3>
                <p class="fctcr-intro"><?php esc_html_e('Select the items you are withdrawing from. All items are pre-selected — uncheck any you want to keep.', 'fluent-cart-customer-rights'); ?></p>

                <div data-fctcr-item-list class="fctcr-item-list"></div>

                <div data-fctcr-sub-section class="fctcr-sub-section" hidden>
                    <div class="fctcr-sub-heading"><?php esc_html_e('Subscription Cancellation', 'fluent-cart-customer-rights'); ?></div>
                    <label class="fctcr-radio-label">
                        <input type="radio" name="fctcr_sub_timing" value="immediate" checked>
                        <?php esc_html_e('Cancel immediately', 'fluent-cart-customer-rights'); ?>
                    </label>
                    <label class="fctcr-radio-label">
                        <input type="radio" name="fctcr_sub_timing" value="next_cycle">
                        <?php esc_html_e('Cancel at next billing cycle', 'fluent-cart-customer-rights'); ?>
                    </label>
                </div>

                <div class="fctcr-global-err" data-fctcr-items-error role="alert" hidden></div>

                <button type="button" class="fctcr-btn-primary" data-fctcr-items-continue><?php esc_html_e('Continue', 'fluent-cart-customer-rights'); ?></button>
                <button type="button" class="fctcr-btn-back" data-fctcr-items-back><?php esc_html_e('Back to edit details', 'fluent-cart-customer-rights'); ?></button>
            </section>

            <!-- Step 2: review + statutory confirmation function -->
            <section data-fctcr-step="confirm" hidden>
                <h3 class="fctcr-step-title"><?php esc_html_e('Review and confirm', 'fluent-cart-customer-rights'); ?></h3>

                <div class="fctcr-notice fctcr-notice-info" data-fctcr-unverified hidden>
                    <?php esc_html_e('We could not automatically match an order with these details. Your withdrawal will still be submitted and reviewed by the store.', 'fluent-cart-customer-rights'); ?>
                </div>

                <div class="fctcr-notice fctcr-notice-warning" data-fctcr-existing hidden></div>

                <!-- Order is outside the configured cancellation window (soft warning) -->
                <div class="fctcr-notice fctcr-notice-warning" data-fctcr-window-warning hidden></div>

                <!-- All items in the order are excluded from the right of withdrawal -->
                <div class="fctcr-notice fctcr-notice-warning fctcr-notice-block" data-fctcr-excluded-all hidden>
                    <strong><?php esc_html_e('This order may not be eligible for withdrawal', 'fluent-cart-customer-rights'); ?></strong>
                    <p><?php esc_html_e('The following items are generally excluded from the right of withdrawal under Art. 16 of the Consumer Rights Directive:', 'fluent-cart-customer-rights'); ?></p>
                    <ul data-fctcr-excluded-items></ul>
                    <p><?php esc_html_e('You can still submit your declaration. The store will review the eligibility of your request and contact you.', 'fluent-cart-customer-rights'); ?></p>
                </div>

                <!-- Some items are excluded — consumer should use the comment field to scope -->
                <div class="fctcr-notice fctcr-notice-info fctcr-notice-block" data-fctcr-excluded-partial hidden>
                    <strong><?php esc_html_e('This order contains items excluded from the right of withdrawal', 'fluent-cart-customer-rights'); ?></strong>
                    <ul data-fctcr-excluded-items></ul>
                    <p><?php esc_html_e('If you only want to withdraw from the eligible items, go back and use the item selection step.', 'fluent-cart-customer-rights'); ?></p>
                </div>

                <div class="fctcr-order" data-fctcr-order hidden>
                    <div class="fctcr-order-head"><strong data-fctcr-order-number></strong><span data-fctcr-order-date></span></div>
                    <ul data-fctcr-order-items></ul>
                    <div class="fctcr-order-total"><span><?php esc_html_e('Total', 'fluent-cart-customer-rights'); ?></span><span data-fctcr-order-total></span></div>
                </div>

                <div class="fctcr-review">
                    <div class="fctcr-review-head"><?php esc_html_e('Your withdrawal request', 'fluent-cart-customer-rights'); ?></div>
                    <dl>
                        <dt><?php esc_html_e('Name', 'fluent-cart-customer-rights'); ?></dt><dd data-fctcr-rv="name"></dd>
                        <dt><?php esc_html_e('Receipt number', 'fluent-cart-customer-rights'); ?></dt><dd data-fctcr-rv="order"></dd>
                        <dt><?php esc_html_e('Email', 'fluent-cart-customer-rights'); ?></dt><dd data-fctcr-rv="email"></dd>
                        <?php if ($showComment): ?><dt class="fctcr-rv-note-row" hidden><?php esc_html_e('Note', 'fluent-cart-customer-rights'); ?></dt><dd class="fctcr-rv-note-row" data-fctcr-rv="message" hidden></dd><?php endif; ?>
                        <dt class="fctcr-rv-items-row" hidden><?php esc_html_e('Items to withdraw', 'fluent-cart-customer-rights'); ?></dt><dd class="fctcr-rv-items-row" data-fctcr-rv="items" hidden></dd>
                        <dt class="fctcr-rv-sub-row" hidden><?php esc_html_e('Subscription', 'fluent-cart-customer-rights'); ?></dt><dd class="fctcr-rv-sub-row" data-fctcr-rv="sub_timing" hidden></dd>
                        <dt class="fctcr-rv-total-row" hidden><?php esc_html_e('Est. refund', 'fluent-cart-customer-rights'); ?></dt><dd class="fctcr-rv-total-row" data-fctcr-rv="estimated_total" hidden></dd>
                    </dl>
                </div>

                <div class="fctcr-global-err" data-fctcr-confirm-error role="alert" hidden></div>

                <?php /* Statutory label, § 356a Abs. 3 — exactly this wording, nothing appended */ ?>
                <button type="button" class="fctcr-btn-primary" data-fctcr-confirm><?php esc_html_e('Confirm withdrawal', 'fluent-cart-customer-rights'); ?></button>
                <button type="button" class="fctcr-btn-back" data-fctcr-back><?php esc_html_e('Back to edit details', 'fluent-cart-customer-rights'); ?></button>
            </section>

            <!-- Step 3: acknowledgment of receipt -->
            <section data-fctcr-step="success" hidden>
                <div class="fctcr-success-icon" aria-hidden="true">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </div>
                <h3 class="fctcr-step-title fctcr-center"><?php esc_html_e('Your withdrawal has been received', 'fluent-cart-customer-rights'); ?></h3>
                <p class="fctcr-center fctcr-muted">
                    <?php esc_html_e('We have sent an acknowledgment of receipt to', 'fluent-cart-customer-rights'); ?>
                    <strong data-fctcr-sx-email></strong>
                </p>
                <p class="fctcr-center fctcr-muted fctcr-small"><?php esc_html_e('This acknowledgment confirms receipt of your declaration. The store will review your request and contact you about the next steps.', 'fluent-cart-customer-rights'); ?></p>

                <div class="fctcr-review fctcr-receipt">
                    <div class="fctcr-review-head"><?php esc_html_e('Acknowledgment of receipt', 'fluent-cart-customer-rights'); ?></div>
                    <dl>
                        <dt><?php esc_html_e('Received on', 'fluent-cart-customer-rights'); ?></dt><dd data-fctcr-sx-time></dd>
                        <dt><?php esc_html_e('Name', 'fluent-cart-customer-rights'); ?></dt><dd data-fctcr-sx-name></dd>
                        <dt><?php esc_html_e('Receipt number', 'fluent-cart-customer-rights'); ?></dt><dd data-fctcr-sx-order></dd>
                        <dt><?php esc_html_e('Reference', 'fluent-cart-customer-rights'); ?></dt><dd data-fctcr-sx-ref></dd>
                    </dl>
                </div>
            </section>
        </div>
        <?php

        return ob_get_clean();
    }

    /**
     * Resolves the order a deep link points at. The subscription uuid is a
     * private token, so it is trusted on its own; a bare ?order= reference is
     * guessable and only trusted when the logged-in user owns the order.
     *
     * @return object|null
     */
    private function resolveContextOrder($prefillOrder)
    {
        if (!class_exists('\FluentCart\App\Models\Order')) {
            return null;
        }

        if (!empty($_GET['subscription']) && class_exists('\FluentCart\App\Models\Subscription')) {
            $uuid = sanitize_text_field(wp_unslash($_GET['subscription']));
            $subscription = \FluentCart\App\Models\Subscription::where('uuid', $uuid)->first();
            if ($subscription && !empty($subscription->parent_order_id)) {
                return \FluentCart\App\Models\Order::find($subscription->parent_order_id);
            }
        }

        if ($prefillOrder && is_user_logged_in()) {
            $ref = ltrim(trim($prefillOrder), '#');
            $order = $ref !== '' ? \FluentCart\App\Models\Order::where('invoice_no', $ref)->orderByDesc('id')->first() : null;
            if ($order && $order->customer && (int)$order->customer->user_id === get_current_user_id()) {
                return $order;
            }
        }

        return null;
    }

    private function existingRequestPanel($request)
    {
        $reference = strtoupper(substr($request->uuid, 0, 8));
        $receivedAt = get_date_from_gmt($request->submitted_at, get_option('date_format') . ' ' . get_option('time_format'));

        if ($request->status === 'pending') {
            $title = __('A withdrawal request for this order is already on record', 'fluent-cart-customer-rights');
            $body = __('The store is reviewing it and will contact you about the next steps. You do not need to submit it again.', 'fluent-cart-customer-rights');
            $class = 'fctcr-notice-warning';
        } elseif ($request->status === 'accepted') {
            $title = __('Your withdrawal request for this order was accepted', 'fluent-cart-customer-rights');
            $body = __('The store has accepted your withdrawal. Please contact the store if you have any further questions.', 'fluent-cart-customer-rights');
            $class = 'fctcr-notice-success';
        } else {
            $title = __('Your withdrawal request for this order was not accepted', 'fluent-cart-customer-rights');
            $body = __('Please reply to the decision email if you believe this was a mistake.', 'fluent-cart-customer-rights');
            $class = 'fctcr-notice-warning';
        }

        /* translators: %1$s: request reference code, %2$s: date and time the request was received */
        $metaLine = sprintf(__('Reference %1$s — received %2$s', 'fluent-cart-customer-rights'), $reference, $receivedAt);

        return '<div class="fctcr-notice ' . esc_attr($class) . ' fctcr-status-panel">'
            . '<strong>' . esc_html($title) . '</strong>'
            . '<div class="fctcr-status-meta">' . esc_html($metaLine) . '</div>'
            . '<div>' . esc_html($body) . '</div>'
            . '</div>';
    }

    private function enqueueAssets()
    {
        wp_enqueue_style(
            'fctcr-form',
            FLUENT_CART_CUSTOMER_RIGHTS_URL . 'assets/css/form.min.css',
            [],
            FLUENT_CART_CUSTOMER_RIGHTS_VERSION
        );

        wp_enqueue_script(
            'fctcr-form',
            FLUENT_CART_CUSTOMER_RIGHTS_URL . 'assets/js/form.min.js',
            [],
            FLUENT_CART_CUSTOMER_RIGHTS_VERSION,
            ['in_footer' => true]
        );

        wp_localize_script('fctcr-form', 'fctcrVars', [
            'ajax_url'        => admin_url('admin-ajax.php'),
            'show_comment'    => Settings::getShowCommentField() && Settings::getPartialRevocationsPermitted(),
            'i18n'            => [
                'generic_error'   => __('Something went wrong — please try again.', 'fluent-cart-customer-rights'),
                'checking'        => __('Checking…', 'fluent-cart-customer-rights'),
                'submitting'      => __('Submitting…', 'fluent-cart-customer-rights'),
                'continue'        => __('Continue', 'fluent-cart-customer-rights'),
                'confirm'             => __('Confirm withdrawal', 'fluent-cart-customer-rights'),
                'select_at_least_one' => __('Please select at least one item to withdraw.', 'fluent-cart-customer-rights'),
                'all_items'           => __('All items', 'fluent-cart-customer-rights'),
                'qty_label'           => __('Qty:', 'fluent-cart-customer-rights'),
                'sub_immediately'     => __('Cancel immediately', 'fluent-cart-customer-rights'),
                'sub_next_cycle'      => __('Cancel at next billing cycle', 'fluent-cart-customer-rights'),
                /* translators: %1$s: request status, %2$s: date and time of the earlier request */
                'existing'        => __('A withdrawal request for this order is already on record — status: %1$s, received %2$s. The store will contact you about it.', 'fluent-cart-customer-rights'),
                /* translators: %1$s: date and time of the earlier request */
                'last_accepted'   => __('Note: a withdrawal request for this order was already accepted — received %1$s. Only continue if something else needs withdrawing.', 'fluent-cart-customer-rights'),
                /* translators: %1$s: date and time of the earlier request */
                'last_declined'   => __('Note: an earlier withdrawal request for this order was declined — received %1$s. You can still submit a new declaration.', 'fluent-cart-customer-rights'),
            ],
        ]);
    }

}
