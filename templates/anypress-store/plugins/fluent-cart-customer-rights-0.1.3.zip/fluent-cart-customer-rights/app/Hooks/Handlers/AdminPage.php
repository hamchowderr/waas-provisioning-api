<?php

namespace FluentCartCustomerRights;

defined('ABSPATH') or die;

class AdminPage
{
    public function register()
    {
        add_filter('fluent_cart/widgets/single_order_page', [$this, 'orderWidget'], 10, 2);
        add_action('admin_post_fctcr_update_status', [$this, 'handleUpdateStatus']);

        // SPA integration (like the Licenses page): the Vue page is compiled by
        // core (resources/withdrawal/withdrawal.js) and registers the
        // #/withdrawal-requests route via the fluent_cart_routes JS filter.
        add_action('fluent_cart/loading_app', [$this, 'enqueueAppScript']);
        add_filter('fluent_cart/global_admin_menu_more_items', [$this, 'addMenuItem'], 10, 2);

        // Table config for the table-new base class (search guide, advanced
        // filter options) — keyed by the JS table name.
        add_filter('fluent_cart/admin_filter_options', [$this, 'addFilterOptions'], 10, 2);
        add_filter('fluent_cart/admin_table_saved_views', [$this, 'addTableConfig'], 10, 2);

        add_filter('fluent_cart/admin_translations', [$this, 'addTranslations']);
    }

    public function addFilterOptions($filterOptions, $args)
    {
        if (!is_array($filterOptions)) {
            $filterOptions = [];
        }

        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Models/WithdrawalRequest.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Services/RequestFilter.php';

        $filterOptions['withdrawal_request_filter_options'] = RequestFilter::getTableFilterOptions();

        return $filterOptions;
    }

    public function addTableConfig($tableConfig, $args)
    {
        if (!is_array($tableConfig)) {
            $tableConfig = [];
        }

        $filterOptions = isset($args['filterOptions']) ? $args['filterOptions'] : [];

        if (!isset($tableConfig['withdrawal_requests'])) {
            $tableConfig['withdrawal_requests'] = [];
        }
        $tableConfig['withdrawal_requests']['filters'] = isset($filterOptions['withdrawal_request_filter_options'])
            ? $filterOptions['withdrawal_request_filter_options']
            : [];

        return $tableConfig;
    }

    public function addTranslations($translations)
    {
        $strings = [
            'Accept'                                                              => __('Accept', 'fluent-cart-customer-rights'),
            'Decline'                                                             => __('Decline', 'fluent-cart-customer-rights'),
            'Est. Refund'                                                         => __('Est. Refund', 'fluent-cart-customer-rights'),
            'Link order'                                                          => __('Link order', 'fluent-cart-customer-rights'),
            'No withdrawal requests found based on your filter'                   => __('No withdrawal requests found based on your filter', 'fluent-cart-customer-rights'),
            'Not matched'                                                         => __('Not matched', 'fluent-cart-customer-rights'),
            'Please enter a valid order ID.'                                      => __('Please enter a valid order ID.', 'fluent-cart-customer-rights'),
            'Qty requested'                                                       => __('Qty requested', 'fluent-cart-customer-rights'),
            'Received'                                                            => __('Received', 'fluent-cart-customer-rights'),
            'Reference'                                                           => __('Reference', 'fluent-cart-customer-rights'),
            'That action could not be completed.'                                 => __('That action could not be completed.', 'fluent-cart-customer-rights'),
            'That order could not be linked.'                                     => __('That order could not be linked.', 'fluent-cart-customer-rights'),
            'The request has been updated and the customer was notified by email.' => __('The request has been updated and the customer was notified by email.', 'fluent-cart-customer-rights'),
            'The request is now linked to the order and marked verified.'          => __('The request is now linked to the order and marked verified.', 'fluent-cart-customer-rights'),
            'Verified'                                                            => __('Verified', 'fluent-cart-customer-rights'),
            'Verified Mail'                                                       => __('Verified Mail', 'fluent-cart-customer-rights'),
            'Verified User'                                                       => __('Verified User', 'fluent-cart-customer-rights'),
            'Withdrawal Requests'                                                 => __('Withdrawal Requests', 'fluent-cart-customer-rights'),
        ];

        return array_merge($translations, $strings);
    }

    public function enqueueAppScript()
    {
        if (class_exists('\FluentCart\App\Vite')) {
            \FluentCart\App\Vite::enqueueScript('fctcr_admin', 'withdrawal/withdrawal.js');
        }
    }

    public function addMenuItem($items, $args)
    {
        if (!is_array($items)) {
            $items = [];
        }

        $baseUrl = isset($args['base_url']) ? $args['base_url'] : admin_url('admin.php?page=fluent-cart#/');

        $items['withdrawal_requests'] = [
            'label'      => __('Withdrawals', 'fluent-cart-customer-rights'),
            'link'       => $baseUrl . 'withdrawal-requests',
            'permission' => ['orders/view'],
        ];

        return $items;
    }

    /* ───────────────────────── Single-order widget ───────────────────────── */

    public function orderWidget($widgets, $data)
    {
        if (!is_array($widgets)) {
            $widgets = [];
        }

        $order = isset($data['order']) ? $data['order'] : null;
        if (!$order || empty($order->id)) {
            return $widgets;
        }

        $requests = (new RequestModel())->getByOrderId($order->id);
        if (!$requests) {
            return $widgets;
        }

        $redirect = admin_url('admin.php?page=fluent-cart#/orders/' . (int)$order->id . '/view');

        $content = $this->widgetStyles();
        foreach ($requests as $request) {
            $content .= $this->requestCardHtml($request, $redirect);
        }

        /* translators: %1$d: number of withdrawal requests on this order */
        $title = sprintf(__('Withdrawal Requests (%1$d)', 'fluent-cart-customer-rights'), count($requests));

        $widgets[] = [
            'title'   => $title,
            'type'    => 'html',
            'content' => $content,
        ];

        return $widgets;
    }

    private function requestCardHtml($request, $redirect)
    {
        $statusClass = in_array($request->status, ['accepted', 'declined'], true) ? 'is-' . $request->status : 'is-pending';

        $receivedAt = get_date_from_gmt($request->submitted_at, get_option('date_format') . ' ' . get_option('time_format'));
        $reference = strtoupper(substr($request->uuid, 0, 8));

        $meta = ($request->meta && is_string($request->meta)) ? json_decode($request->meta, true) : [];
        if (!is_array($meta)) {
            $meta = [];
        }
        $excludedItems = !empty($meta['excluded_items']) && is_array($meta['excluded_items']) ? $meta['excluded_items'] : [];
        $allExcluded = !empty($meta['all_excluded']);
        $estimatedRefund = isset($meta['estimated_refund']) ? (int)$meta['estimated_refund'] : null;
        $estimatedRefundCurrency = isset($meta['estimated_refund_currency']) ? (string)$meta['estimated_refund_currency'] : '';

        $html = '<div class="fctcr-adm-card ' . esc_attr($statusClass) . '">';

        $html .= '<div class="fctcr-adm-badges">';
        $html .= '<span class="fctcr-adm-badge fctcr-adm-badge-status">' . esc_html($this->statusLabel($request->status)) . '</span>';
        $html .= $request->is_verified
            ? '<span class="fctcr-adm-badge fctcr-adm-badge-ok">' . esc_html__('Verified', 'fluent-cart-customer-rights') . '</span>'
            : '<span class="fctcr-adm-badge fctcr-adm-badge-muted">' . esc_html__('Unverified', 'fluent-cart-customer-rights') . '</span>';
        if ($excludedItems) {
            $badgeLabel = $allExcluded
                ? __('All items excluded', 'fluent-cart-customer-rights')
                : __('Partial exclusion', 'fluent-cart-customer-rights');
            $html .= '<span class="fctcr-adm-badge fctcr-adm-badge-excluded">' . esc_html($badgeLabel) . '</span>';
        }
        $html .= '<span class="fctcr-adm-ref">' . esc_html($reference) . '</span>';
        $html .= '</div>';

        $labelReceived = __('Received', 'fluent-cart-customer-rights');
        $labelName = __('Name', 'fluent-cart-customer-rights');
        $labelOrderRef = __('Order ref', 'fluent-cart-customer-rights');
        $labelNote = __('Part / note', 'fluent-cart-customer-rights');

        $html .= '<div class="fctcr-adm-rows">';
        $html .= $this->rowHtml($labelReceived, $receivedAt);
        $html .= $this->rowHtml($labelName, $request->name . ' — ' . $request->email);
        $html .= $this->rowHtml($labelOrderRef, $request->order_reference);
        if ($request->message !== '' && $request->message !== null) {
            $html .= $this->rowHtml($labelNote, $request->message);
        }
        if ($excludedItems) {
            $excludedLabel = __('Excl. items', 'fluent-cart-customer-rights');
            $html .= $this->rowHtml($excludedLabel, implode(', ', $excludedItems));
        }
        if ($estimatedRefund !== null && $estimatedRefund > 0) {
            $refundDisplay = \FluentCart\App\Helpers\Helper::toDecimal($estimatedRefund, true, $estimatedRefundCurrency ?: null);
            $html .= $this->rowHtml(__('Est. refund', 'fluent-cart-customer-rights'), $refundDisplay);
        }
        $html .= '</div>';

        if ($request->status === 'pending' && $this->canManage()) {
            $html .= '<div class="fctcr-adm-actions">';
            $html .= '<a class="fctcr-adm-btn fctcr-adm-btn-accept" href="' . esc_url($this->statusActionUrl($request->id, 'accepted', $redirect)) . '">' . esc_html__('Accept withdrawal', 'fluent-cart-customer-rights') . '</a>';
            $html .= '<a class="fctcr-adm-btn fctcr-adm-btn-decline" href="' . esc_url($this->statusActionUrl($request->id, 'declined', $redirect)) . '">' . esc_html__('Decline', 'fluent-cart-customer-rights') . '</a>';
            $html .= '<span class="fctcr-adm-hint">' . esc_html__('The customer is emailed automatically. Refunds stay manual.', 'fluent-cart-customer-rights') . '</span>';
            $html .= '</div>';
        } elseif ($request->status !== 'pending') {
            $actor = $request->processed_by ? get_userdata((int)$request->processed_by) : null;
            $actorName = $actor ? $actor->display_name : __('admin', 'fluent-cart-customer-rights');
            $processedAt = $request->processed_at ? get_date_from_gmt($request->processed_at, get_option('date_format') . ' ' . get_option('time_format')) : '';

            /* translators: %1$s: accepted/declined label, %2$s: admin user name, %3$s: date and time */
            $processedLine = sprintf(__('%1$s by %2$s on %3$s — decision email sent to the customer.', 'fluent-cart-customer-rights'), $this->statusLabel($request->status), $actorName, $processedAt);

            $html .= '<div class="fctcr-adm-processed">' . esc_html($processedLine) . '</div>';
        }

        $detailsUrl = admin_url('admin.php') . '?page=fluent-cart#/withdrawal-requests/?search=' . rawurlencode($reference);
        $html .= '<div class="fctcr-adm-footer"><a class="fctcr-adm-details-link" href="' . esc_url($detailsUrl) . '" target="_blank" rel="noopener">' . esc_html__('View details', 'fluent-cart-customer-rights') . ' &rarr;</a></div>';

        $html .= '</div>';

        return $html;
    }

    private function rowHtml($label, $value)
    {
        return '<div class="fctcr-adm-row"><span class="fctcr-adm-key">' . esc_html($label) . '</span><span class="fctcr-adm-val">' . esc_html($value) . '</span></div>';
    }

    private function widgetStyles()
    {
        // Status palettes live in CSS classes (not inline styles) so dark mode
        // can override them — the admin toggles a `dark` class on the wrapper.
        return '<style>
            .fctcr-adm-card{border:1px solid;border-radius:8px;padding:14px 16px;margin:0 0 12px;font-size:13px;}
            .fctcr-adm-card.is-pending{background:#FFF9F3;border-color:#FDE8CD;}
            .fctcr-adm-card.is-accepted{background:#F3FAF8;border-color:#D1EAE4;}
            .fctcr-adm-card.is-declined{background:#FEF6F4;border-color:#F8D6CE;}
            .fctcr-adm-badges{display:flex;align-items:center;gap:8px;margin-bottom:10px;}
            .fctcr-adm-badge{display:inline-block;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:600;text-transform:capitalize;}
            .is-pending .fctcr-adm-badge-status{background:#FDE8CD;color:#AC6305;}
            .is-accepted .fctcr-adm-badge-status{background:#D1EAE4;color:#116A53;}
            .is-declined .fctcr-adm-badge-status{background:#F8D6CE;color:#9B2406;}
            .fctcr-adm-badge-ok{background:#D1EAE4;color:#116A53;}
            .fctcr-adm-badge-muted{background:#F3F4F6;color:#2F3448;}
            .fctcr-adm-badge-excluded{background:#FDE8CD;color:#AC6305;}
            .fctcr-adm-ref{margin-left:auto;color:#6B7280;font-size:11px;letter-spacing:.04em;}
            .fctcr-adm-row{display:flex;gap:10px;padding:3px 0;}
            .fctcr-adm-key{flex:0 0 80px;color:#565865;}
            .fctcr-adm-val{color:#1F2937;font-weight:500;overflow-wrap:anywhere;}
            .fctcr-adm-actions{display:flex;align-items:center;gap:8px;margin-top:12px;flex-wrap:wrap;}
            .fctcr-adm-btn{display:inline-block;padding:6px 14px;border-radius:6px;font-size:12.5px;font-weight:600;text-decoration:none;}
            .fctcr-adm-btn-accept{background:#189877;color:#fff;}
            .fctcr-adm-btn-decline{background:#fff;color:#9B2406;border:1px solid #F8D6CE;}
            .fctcr-adm-hint{color:#6B7280;font-size:11.5px;}
            .fctcr-adm-processed{margin-top:10px;color:#565865;font-size:12.5px;}
            .fctcr-adm-footer{margin-top:10px;text-align:right;}
            .fctcr-adm-details-link{font-size:12px;color:#2563EB;text-decoration:none;}
            .fctcr-adm-details-link:hover{text-decoration:underline;}

            .dark .fctcr-adm-card.is-pending{background:#2A2118;border-color:#7A4A04;}
            .dark .fctcr-adm-card.is-accepted{background:#14241F;border-color:#116A53;}
            .dark .fctcr-adm-card.is-declined{background:#2A1A16;border-color:#7A2010;}
            .dark .is-pending .fctcr-adm-badge-status{background:#7A4A04;color:#FDE8CD;}
            .dark .is-accepted .fctcr-adm-badge-status{background:#116A53;color:#D1EAE4;}
            .dark .is-declined .fctcr-adm-badge-status{background:#7A2010;color:#F8D6CE;}
            .dark .fctcr-adm-badge-ok{background:#116A53;color:#D1EAE4;}
            .dark .fctcr-adm-badge-muted{background:#2D333B;color:#D1D5DB;}
            .dark .fctcr-adm-badge-excluded{background:#7A4A04;color:#FDE8CD;}
            .dark .fctcr-adm-ref{color:#8A93A2;}
            .dark .fctcr-adm-key{color:#9CA3AF;}
            .dark .fctcr-adm-val{color:#F9FAFB;}
            .dark .fctcr-adm-btn-decline{background:transparent;color:#F8D6CE;border-color:#7A2010;}
            .dark .fctcr-adm-hint{color:#8A93A2;}
            .dark .fctcr-adm-processed{color:#D1D5DB;}
            .dark .fctcr-adm-details-link{color:#60A5FA;}
        </style>';
    }

    /* ───────────────────────── admin-post handlers ───────────────────────── */

    public function handleUpdateStatus()
    {
        $requestId = isset($_GET['request_id']) ? absint($_GET['request_id']) : 0;

        if (!$this->canManage()) {
            wp_die(esc_html__('You are not allowed to do this.', 'fluent-cart-customer-rights'));
        }
        check_admin_referer('fctcr_update_status_' . $requestId);

        $status = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : '';
        $result = (new WithdrawalService())->updateStatus($requestId, $status, get_current_user_id());

        $this->redirectBack($result ? 'updated' : 'failed');
    }

    private function redirectBack($message)
    {
        $raw = '';
        if (isset($_REQUEST['redirect'])) {
            $raw = esc_url_raw(rawurldecode(wp_unslash($_REQUEST['redirect'])));
        }

        // Only allow redirects back into wp-admin; the SPA hash survives the roundtrip.
        $fallback = admin_url('admin.php?page=fluent-cart#/withdrawal-requests');
        $target = (strpos($raw, admin_url('admin.php')) === 0) ? $raw : $fallback;

        // The SPA hash must stay at the very end of the URL.
//        if (strpos($target, '#') !== false) {
//            list($base, $hash) = explode('#', $target, 2);
//            $target = add_query_arg('fctcr_msg', $message, $base) . '#' . $hash;
//        } else {
//            $target = add_query_arg('fctcr_msg', $message, $target);
//        }

        wp_safe_redirect($target);
        exit;
    }

    /* ───────────────────────── helpers ───────────────────────── */

    private function statusActionUrl($requestId, $status, $redirect)
    {
        $url = add_query_arg([
            'action'     => 'fctcr_update_status',
            'request_id' => (int)$requestId,
            'status'     => $status,
            'redirect'   => rawurlencode($redirect),
        ], admin_url('admin-post.php'));

        return wp_nonce_url($url, 'fctcr_update_status_' . (int)$requestId);
    }

    private function statusLabel($status)
    {
        $labels = [
            'pending'  => __('Pending', 'fluent-cart-customer-rights'),
            'accepted' => __('Accepted', 'fluent-cart-customer-rights'),
            'declined' => __('Declined', 'fluent-cart-customer-rights'),
        ];

        return isset($labels[$status]) ? $labels[$status] : $status;
    }

    private function canManage()
    {
        if (class_exists('\FluentCart\App\Services\Permission\PermissionManager')) {
            if (\FluentCart\App\Services\Permission\PermissionManager::hasPermission(['orders/manage'])) {
                return true;
            }
        }

        return current_user_can('manage_options');
    }
}
