<?php

namespace FluentCartCustomerRights;

use FluentCart\App\Models\Model;

defined('ABSPATH') or die;

/**
 * ORM model for fctcr_requests — used by the BaseFilter-driven admin table.
 * (RequestModel is the lightweight $wpdb sibling used by the public flow.)
 */
class WithdrawalRequest extends Model
{
    protected $table = 'fctcr_requests';

    // MySQL hands these back as strings; "0" is truthy in JS, so the admin
    // table would render every request as verified without the casts.
    protected $casts = [
        'is_verified'  => 'boolean',
        'order_id'     => 'integer',
        'customer_id'  => 'integer',
        'processed_by' => 'integer',
    ];

    protected $fillable = [
        'uuid',
        'order_id',
        'customer_id',
        'is_verified',
        'status',
        'name',
        'email',
        'order_reference',
        'message',
        'source',
        'ip_address',
        'submitted_at',
        'processed_at',
        'processed_by',
        'meta',
    ];

    public function order()
    {
        return $this->belongsTo('\FluentCart\App\Models\Order', 'order_id');
    }
}
