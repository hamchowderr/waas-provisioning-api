<?php

namespace FluentCartCustomerRights;

defined('ABSPATH') or die;

class RequestModel
{
    protected $tableName = 'fctcr_requests';

    public function table()
    {
        global $wpdb;

        return $wpdb->prefix . $this->tableName;
    }

    public function find($id)
    {
        global $wpdb;
        $table = $this->table();

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));
    }

    public function findByUuid($uuid)
    {
        global $wpdb;
        $table = $this->table();

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE uuid = %s", $uuid));
    }

    public function getOpenByOrderId($orderId)
    {
        global $wpdb;
        $table = $this->table();

        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table WHERE order_id = %d AND status = %s ORDER BY id DESC", $orderId, 'pending')
        );
    }

    /**
     * Finds an open (pending) request submitted with the same typed identity —
     * the unverified-path equivalent of getOpenByOrderId(). Email is compared
     * case-insensitively; references are normalized ('#'-stripped, trimmed).
     *
     * @return object|null
     */
    public function getOpenByIdentity($email, $orderReference)
    {
        global $wpdb;
        $table = $this->table();

        $candidates = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE status = %s AND LOWER(email) = %s ORDER BY id DESC",
            'pending',
            strtolower(trim($email))
        ));

        $needle = $this->normalizeReference($orderReference);

        foreach ($candidates as $candidate) {
            if ($this->normalizeReference($candidate->order_reference) === $needle) {
                return $candidate;
            }
        }

        return null;
    }

    private function normalizeReference($reference)
    {
        return strtolower(ltrim(trim((string)$reference), '#'));
    }

    public function getByOrderId($orderId)
    {
        global $wpdb;
        $table = $this->table();

        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM $table WHERE order_id = %d ORDER BY id DESC", $orderId)
        );
    }

    /**
     * @param string $filter all | pending | accepted | declined | unverified
     */
    public function getList($filter = 'all', $limit = 50, $offset = 0)
    {
        global $wpdb;
        $table = $this->table();

        if ($filter === 'unverified') {
            $sql = $wpdb->prepare("SELECT * FROM $table WHERE is_verified = 0 ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset);
        } elseif (in_array($filter, ['pending', 'accepted', 'declined'], true)) {
            $sql = $wpdb->prepare("SELECT * FROM $table WHERE status = %s ORDER BY id DESC LIMIT %d OFFSET %d", $filter, $limit, $offset);
        } else {
            $sql = $wpdb->prepare("SELECT * FROM $table ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset);
        }

        return $wpdb->get_results($sql);
    }

    public function getCounts()
    {
        global $wpdb;
        $table = $this->table();

        $counts = [
            'all'        => (int)$wpdb->get_var("SELECT COUNT(*) FROM $table"),
            'unverified' => (int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE is_verified = 0"),
            'pending'    => 0,
            'accepted'   => 0,
            'declined'   => 0,
        ];

        $rows = $wpdb->get_results("SELECT status, COUNT(*) AS total FROM $table GROUP BY status");
        foreach ($rows as $row) {
            if (isset($counts[$row->status])) {
                $counts[$row->status] = (int)$row->total;
            }
        }

        return $counts;
    }

    public function update($id, $data)
    {
        global $wpdb;

        $data['updated_at'] = gmdate('Y-m-d H:i:s');

        return $wpdb->update($this->table(), $data, ['id' => (int)$id]);
    }

    /**
     * @param array $data
     * @return object|null The created row, or null on failure.
     */
    public function create($data)
    {
        global $wpdb;

        $now = gmdate('Y-m-d H:i:s');

        $row = wp_parse_args($data, [
            'uuid'            => md5(time() . wp_generate_uuid4()),
            'order_id'        => null,
            'customer_id'     => null,
            'is_verified'     => 0,
            'status'          => 'pending',
            'name'            => '',
            'email'           => '',
            'order_reference' => '',
            'message'         => '',
            'source'          => 'public_form',
            'ip_address'      => '',
            'submitted_at'    => $now, // statutory date+time of receipt (GMT)
            'created_at'      => $now,
            'updated_at'      => $now,
        ]);

        $inserted = $wpdb->insert($this->table(), $row);

        if (!$inserted) {
            return null;
        }

        return $this->find($wpdb->insert_id);
    }
}
