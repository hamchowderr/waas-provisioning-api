<?php

namespace FluentCartCustomerRights;

use FluentCart\App\Services\Filter\BaseFilter;

defined('ABSPATH') or die;

class RequestFilter extends BaseFilter
{
    public string $defaultSortBy = 'id';

    public function applySimpleFilter(?string $search = null): void
    {
        $isApplied = $this->applySimpleOperatorFilter($search);
        if ($isApplied) {
            return;
        }

        $this->query->when($search ?? $this->search, function ($query, $search) {
            $search = is_array($search) ? implode(' ', $search) : $search;

            if (empty($search)) {
                return $query;
            }

            $query->where(function ($query) use ($search) {
                $query->where('name', 'like', '%' . $search . '%')
                    ->orWhere('email', 'like', '%' . $search . '%')
                    ->orWhere('order_reference', 'like', '%' . $search . '%')
                    ->orWhere('uuid', 'like', '%' . $search . '%');

                if (is_numeric($search)) {
                    $query->orWhere('order_id', (int)$search);
                }
            });

            return $query;
        });
    }

    public function tabsMap(): array
    {
        return [
            'pending'    => __('Pending', 'fluent-cart-customer-rights'),
            'accepted'   => __('Accepted', 'fluent-cart-customer-rights'),
            'declined'   => __('Declined', 'fluent-cart-customer-rights'),
            'unverified' => __('Unverified', 'fluent-cart-customer-rights'),
        ];
    }

    public function getModel(): string
    {
        return WithdrawalRequest::class;
    }

    public static function getFilterName(): string
    {
        return 'withdrawal_requests';
    }

    public function applyActiveViewFilter(?string $activeView = null): void
    {
        $activeView = $activeView ?? $this->activeView;

        $this->query->when($activeView, function ($query, $activeView) {
            if (in_array($activeView, ['pending', 'accepted', 'declined'], true)) {
                $query->where('status', $activeView);
            } elseif ($activeView === 'unverified') {
                $query->where('is_verified', 0);
            }

            return $query;
        });
    }
}
