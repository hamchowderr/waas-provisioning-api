<?php

namespace FluentCartCustomerRights;

defined('ABSPATH') or die;

class Renderer
{
    /**
     * Renders a structured footer-parts array into an HTML string.
     *
     * Structured data is filtered upstream via fctcr/customer/{location}_footer_parts
     * before this method is called. Customisation hooks exposed here:
     *
     *   do_action  fctcr/render/before_footer_parts  ( $parts, $location )
     *   do_action  fctcr/render/after_footer_parts   ( $parts, $location )
     *   filter     fctcr/render/footer_wrapper_class  ( $class, $location, $parts )
     *   filter     fctcr/render/footer_inner_class    ( $class, $location, $parts )
     *   filter     fctcr/render/footer_link_class     ( $class, $item, $location )
     *   filter     fctcr/render/footer_text_class     ( $class, $item, $location )
     *
     * @param array  $parts    Items: ['key'=>string, 'state'=>'active|pending|accepted', 'url'=>string, 'label'=>string]
     * @param string $location 'subscription' | 'order' | 'dashboard'
     */
    public static function renderFooterParts(array $parts, string $location = ''): string
    {
        if (empty($parts)) {
            return '';
        }

        $wrapperClass = (string) apply_filters(
            'fctcr/render/footer_wrapper_class',
            'fctcr-footer-actions fct-single-order-footer mt-3',
            ['location' => $location, 'parts' => $parts]
        );

        $innerClass = (string) apply_filters(
            'fctcr/render/footer_inner_class',
            'flex items-center gap-3',
            ['location' => $location, 'parts' => $parts]
        );

        ob_start();

        do_action('fctcr/render/before_footer_parts', $parts, $location);

        echo '<div class="' . esc_attr($wrapperClass) . '">';
        echo '<div class="' . esc_attr($innerClass) . '">';

        foreach ($parts as $item) {
            if (empty($item['key'])) {
                continue;
            }
            echo static::renderItem($item, $location);
        }

        echo '</div></div>';

        do_action('fctcr/render/after_footer_parts', $parts, $location);

        return (string) ob_get_clean();
    }

    private static function renderItem(array $item, string $location): string
    {
        $label = esc_html(isset($item['label']) ? $item['label'] : '');
        $state = isset($item['state']) ? $item['state'] : 'active';

        if ($state === 'active' && !empty($item['url'])) {
            $class = (string) apply_filters('fctcr/render/footer_link_class', 'underline-link-button', ['item' => $item, 'location' => $location]);
            return '<a class="' . esc_attr($class) . '" href="' . esc_url($item['url']) . '">' . $label . '</a>';
        }

        $class = (string) apply_filters('fctcr/render/footer_text_class', 'text', ['item' => $item, 'location' => $location]);
        return '<span class="' . esc_attr($class) . '">' . $label . '</span>';
    }
}
