<?php

namespace FluentCartCustomerRights;

defined('ABSPATH') or die;

class WithdrawalService
{
    const TOKEN_TTL = 900;   // 15 min between identify and confirm
    const RATE_LIMIT = 5;    // attempts per IP
    const RATE_PERIOD = 900; // seconds

    public function registerAjax()
    {
        add_action('wp_ajax_fctcr_identify', [$this, 'ajaxIdentify']);
        add_action('wp_ajax_nopriv_fctcr_identify', [$this, 'ajaxIdentify']);
        add_action('wp_ajax_fctcr_submit', [$this, 'ajaxSubmit']);
        add_action('wp_ajax_nopriv_fctcr_submit', [$this, 'ajaxSubmit']);
    }

    /**
     * Step 1: identification. Never reveals which field failed to match;
     * a declaration is only refused when require_verified_match is on.
     */
    public function ajaxIdentify()
    {
        $this->guardCommon();

        // Honeypot: bots get a success-shaped dead end, nothing is created.
        if (!empty($_POST['fctcr_website'])) {
            wp_send_json_success(['verified' => false, 'token' => '', 'order' => null, 'existing_request' => null]);
        }

        $firstName = isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '';
        $lastName  = isset($_POST['last_name'])  ? sanitize_text_field(wp_unslash($_POST['last_name']))  : '';
        $name      = trim($firstName . ' ' . $lastName);
        $reference = isset($_POST['order_number']) ? sanitize_text_field(wp_unslash($_POST['order_number'])) : '';
        $email     = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';

        $requiredFields = Settings::getRequiredFields();
        $errors = [];

        if (in_array('first_name', $requiredFields, true) && ($firstName === '' || strlen($firstName) > 190)) {
            $errors['first_name'] = __('Please enter your first name.', 'fluent-cart-customer-rights');
        }
        if (in_array('last_name', $requiredFields, true) && ($lastName === '' || strlen($lastName) > 190)) {
            $errors['last_name'] = __('Please enter your last name.', 'fluent-cart-customer-rights');
        }
        if (in_array('order_number', $requiredFields, true) && ($reference === '' || strlen($reference) > 190)) {
            $errors['order_number'] = __('Please enter your receipt number.', 'fluent-cart-customer-rights');
        }
        if (in_array('email', $requiredFields, true) && (!$email || !is_email($email))) {
            $errors['email'] = __('Please enter a valid email address.', 'fluent-cart-customer-rights');
        }
        if (!in_array('email', $requiredFields, true) && $email !== '' && !is_email($email)) {
            $errors['email'] = __('Please enter a valid email address.', 'fluent-cart-customer-rights');
        }
        if ($errors) {
            wp_send_json_error(['errors' => $errors], 422);
        }

        $order = $this->matchOrder($reference, $email);

        if (!$order) {
            // Invoice not found or email mismatch — counts as an unauthorized probe
            // for logged-in users; guests are already gated by the IP counter.
            $this->recordUnauthorizedAttempt();
        }

        if (!$order && Settings::get('require_verified_match') === 'yes') {
            wp_send_json_error([
                'message' => __('We could not match an order with these details — please check your order number and email address.', 'fluent-cart-customer-rights')
            ], 404);
        }

        // Blocked order status (2.3): reject before going further.
        if ($order) {
            $blockedStatuses = Settings::getBlockedOrderStatuses();
            if (!empty($blockedStatuses) && !empty($order->status) && in_array((string)$order->status, $blockedStatuses, true)) {
                wp_send_json_error([
                    'message' => sprintf(
                        /* translators: %s: order status slug (e.g. "cancelled") */
                        __('Withdrawal is not available for this order (status: %s). Please contact the store if you believe this is a mistake.', 'fluent-cart-customer-rights'),
                        esc_html($order->status)
                    )
                ], 422);
            }

            $blockedShippingStatuses = Settings::getBlockedShippingStatuses();
            if (!empty($blockedShippingStatuses) && !empty($order->shipping_status) && in_array((string)$order->shipping_status, $blockedShippingStatuses, true)) {
                wp_send_json_error([
                    'message' => sprintf(
                        /* translators: %s: shipping status slug (e.g. "shipped") */
                        __('Withdrawal is not available for this order (shipping status: %s). Please contact the store if you believe this is a mistake.', 'fluent-cart-customer-rights'),
                        esc_html($order->shipping_status)
                    )
                ], 422);
            }
        }

        // Ownership and auth_mode must be resolved before the token is signed so
        // they can be carried tamper-evidently into ajaxSubmit.
        $isOwner  = $order
            && is_user_logged_in()
            && !empty($order->customer)
            && isset($order->customer->user_id)
            && (int) $order->customer->user_id === get_current_user_id();
        $authMode = $order ? ($isOwner ? 'account_owner' : 'email_verified') : 'unverified';

        $response = [
            'verified'         => (bool)$order,
            'order'            => null,
            'existing_request' => null,
            'token'            => $this->signToken([
                'name'      => $name,
                'reference' => $reference,
                'email'     => $email,
                'order_id'  => $order ? (int)$order->id : 0,
                'verified'  => $order ? 1 : 0,
                'exp'       => time() + self::TOKEN_TTL,
            ]),
        ];

        if ($order) {

            // eligibility setting controls which verified callers can see item data.
            // 'account_owner' = must be the logged-in WP account owner (default).
            // 'email_verified' = invoice + billing email match is sufficient proof
            //   of ownership; matchOrder() already enforced both, so $order being
            //   non-null here means the email check passed.
            $eligibility  = Settings::getItemStepEligibility();
            $canSeeItems  = ($eligibility === 'email_verified') ? true : $isOwner;

            // Item details (titles, quantities, pricing) gated on $canSeeItems.
            // Non-qualifying callers receive nothing — no titles, no pricing, no quantities.
            $itemDetails = [];
            if ($canSeeItems) {
                $orderTaxBehavior = (int)(isset($order->tax_behavior) ? $order->tax_behavior : 0);
                $sortedItems = $this->sortedOrderItems($order);
                $itemIndex = 0;
                foreach ($sortedItems as $item) {
                    $label = $this->buildItemLabel($item);
                    if ($label === '') {
                        continue;
                    }
                    $qty       = (isset($item->quantity) && is_numeric($item->quantity)) ? max(1, (int) $item->quantity) : 1;
                    $variantId = (isset($item->object_id) && is_numeric($item->object_id)) ? (int)$item->object_id : 0;
                    $thumb     = $variantId ? $this->variantThumbnail($variantId) : '';
                    $itemDetails[] = [
                        'id'                 => $itemIndex++,   // 0-based position index; no internal DB ID exposed
                        'title'              => $label,
                        'qty'                => $qty,
                        'unit_price'         => $this->effectiveUnitPrice($item),
                        'unit_refund_amount' => $this->computeUnitRefundAmount($item, $orderTaxBehavior),
                        'thumbnail'          => $thumb,
                    ];
                }
            }

            $exclusionResult = $this->checkExclusions($order);
            $windowWarning   = $this->checkCancellationWindow($order);

            // Hard block: every item in this order falls under an Art. 16 CRD exclusion.
            if ($exclusionResult['all_excluded']) {
                wp_send_json_error([
                    'message' => __('This order is not eligible for withdrawal — all products are excluded from the right of withdrawal.', 'fluent-cart-customer-rights')
                ], 422);
            }

            // Subscription timing is part of the item step — gate it the same way.
            $subscriptionInfo = null;
            if ($canSeeItems && class_exists('\FluentCart\App\Models\Subscription')) {
                $sub = \FluentCart\App\Models\Subscription::where('parent_order_id', (int) $order->id)
                    ->orderByDesc('id')
                    ->first();
                if ($sub && !empty($sub->status) && in_array((string) $sub->status, ['active', 'trialling'], true)) {
                    $subscriptionInfo = ['id' => (int) $sub->id, 'status' => (string) $sub->status];
                }
            }

            $response['order'] = [
                'number'          => (string)($order->invoice_no ?? ''),
                'date'            => get_date_from_gmt($order->created_at, get_option('date_format')),
                'items'           => $itemDetails,
                'total'           => $this->formatAmount($order->total_amount, $order->currency),
                'excluded_items'  => $exclusionResult['excluded'],
                'all_excluded'    => $exclusionResult['all_excluded'],
                'outside_window'  => $windowWarning !== '',
                'window_message'  => $windowWarning,
                'subscription'    => $subscriptionInfo,
                'currency'        => $canSeeItems && !empty($order->currency) ? (string) $order->currency : '',
            ];

            $model = new RequestModel();
            $open = $model->getOpenByOrderId($order->id);
            $decidedHistory = null;
            if ($open) {
                $response['existing_request'] = [
                    'status'       => $open->status,
                    'submitted_at' => get_date_from_gmt($open->submitted_at, get_option('date_format') . ' ' . get_option('time_format')),
                ];
            } else {
                $history = $model->getByOrderId($order->id);
                if ($history) {
                    $decidedHistory = $history[0];
                    $response['last_request'] = [
                        'status'       => $decidedHistory->status,
                        'submitted_at' => get_date_from_gmt($decidedHistory->submitted_at, get_option('date_format') . ' ' . get_option('time_format')),
                    ];
                }
            }

            // Server decides whether to show the item-selection step. Gate on a
            // pending or accepted request — a decline doesn't consume the right
            // to declare again, so the item step still applies to the resubmission.
            $blocksNewDeclaration = $open || ($decidedHistory && $decidedHistory->status === 'accepted');
            $response['show_items_step'] = $canSeeItems && !empty($itemDetails) && !$blocksNewDeclaration;
        } else {
            // Unverified path: dedupe on the typed identity (same email + same
            // order reference, still pending) — the honest-repeat case.
            $model = new RequestModel();
            $openByIdentity = $model->getOpenByIdentity($email, $reference);
            if ($openByIdentity) {
                $response['existing_request'] = [
                    'status'       => $openByIdentity->status,
                    'submitted_at' => get_date_from_gmt($openByIdentity->submitted_at, get_option('date_format') . ' ' . get_option('time_format')),
                ];
            } else {
                $anyByIdentity = $this->findAnyByIdentity($email, $reference);
                if ($anyByIdentity) {
                    $response['last_request'] = [
                        'status'       => $anyByIdentity->status,
                        'submitted_at' => get_date_from_gmt($anyByIdentity->submitted_at, get_option('date_format') . ' ' . get_option('time_format')),
                    ];
                }
            }
        }

        wp_send_json_success($response);
    }

    /**
     * Step 2: the statutory confirmation. Requires a valid signed token from
     * step 1; records the declaration with the GMT date and time of receipt.
     */
    public function ajaxSubmit()
    {
        $this->guardCommon();

        if (!empty($_POST['fctcr_website'])) {
            wp_send_json_success(['reference' => '', 'submitted_at' => '', 'email' => '']);
        }

        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        $payload = $this->verifyToken($token);
        if (!$payload) {
            wp_send_json_error([
                'code'    => 'token_expired',
                'message' => __('Your session has expired — please start again from the first step.', 'fluent-cart-customer-rights')
            ], 410);
        }

        $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
        if (strlen($message) > 2000) {
            $message = substr($message, 0, 2000);
        }
        $source = (isset($_POST['source']) && $_POST['source'] === 'customer_profile') ? 'customer_profile' : 'public_form';

        // Item selection: JSON array of {id, qty} objects chosen by the customer.
        // id = order item row ID from the identify response. Titles and pricing are
        // never trusted from the client — validated and augmented server-side below.
        $selectedItems = [];
        $selectedItemsRaw = isset($_POST['selected_items']) ? wp_unslash($_POST['selected_items']) : '';
        if ($selectedItemsRaw !== '') {
            $decoded = json_decode($selectedItemsRaw, true);
            if (is_array($decoded)) {
                foreach ($decoded as $entry) {
                    if (is_array($entry) && isset($entry['id']) && is_numeric($entry['id'])) {
                        $itemIdx = (int) $entry['id'];
                        $itemQty = (isset($entry['qty']) && is_numeric($entry['qty'])) ? max(1, (int) $entry['qty']) : 1;
                        if ($itemIdx >= 0) {
                            $selectedItems[] = ['id' => $itemIdx, 'qty' => $itemQty];
                        }
                    }
                }
            }
        }

        // Subscription cancellation timing preference (owner + active sub only).
        $subscriptionTiming = '';
        if (isset($_POST['subscription_timing']) && in_array($_POST['subscription_timing'], ['immediate', 'next_cycle'], true)) {
            $subscriptionTiming = sanitize_text_field(wp_unslash($_POST['subscription_timing']));
        }

        $model = new RequestModel();
        $orderId = (int)$payload['order_id'];

        // One open request per matched order: re-confirming returns the
        // existing declaration instead of duplicating it. An accepted request
        // blocks (contract already dissolved); a declined one does not — the
        // consumer can submit a new declaration after a decline.
        if ($orderId) {
            $open = $model->getOpenByOrderId($orderId);
            if ($open) {
                wp_send_json_success($this->formatSubmitted($open));
            }
            $decided = $model->getByOrderId($orderId);
            if (!empty($decided) && $decided[0]->status === 'accepted') {
                wp_send_json_error([
                    'code'    => 'already_submitted',
                    'message' => __('A withdrawal request has already been submitted for this order.', 'fluent-cart-customer-rights'),
                ], 409);
            }
        } else {
            $open = $model->getOpenByIdentity($payload['email'], $payload['reference']);
            if ($open) {
                wp_send_json_success($this->formatSubmitted($open));
            }
            $anyDecided = $this->findAnyByIdentity($payload['email'], $payload['reference']);
            if ($anyDecided && $anyDecided->status === 'accepted') {
                wp_send_json_error([
                    'code'    => 'already_submitted',
                    'message' => __('A withdrawal request has already been submitted for this order reference.', 'fluent-cart-customer-rights'),
                ], 409);
            }
        }

        $order = null;
        if ($orderId && class_exists('\FluentCart\App\Models\Order')) {
            $order = \FluentCart\App\Models\Order::find($orderId);
        }

        // Re-derive auth state entirely server-side at save time — never trust
        // a client-submitted value, even from a signed token.
        $isSubmitOwner = $order
            && is_user_logged_in()
            && !empty($order->customer)
            && isset($order->customer->user_id)
            && (int) $order->customer->user_id === get_current_user_id();
        $authMode = $order
            ? ($isSubmitOwner ? 'account_owner' : 'email_verified')
            : 'unverified';

        // Snapshot excluded items into meta so the admin processor sees which
        // items may not be eligible without having to re-derive it later.
        $metaData = [
            'auth_mode' => $authMode,
        ];
        if ($order) {
            $exclusionResult = $this->checkExclusions($order);
            if (!empty($exclusionResult['excluded'])) {
                $metaData['excluded_items'] = $exclusionResult['excluded'];
                $metaData['all_excluded']   = $exclusionResult['all_excluded'];
            }
            if ($exclusionResult['all_excluded']) {
                wp_send_json_error([
                    'message' => __('This order is not eligible for withdrawal — all products are excluded from the right of withdrawal.', 'fluent-cart-customer-rights')
                ], 422);
            }
        }

        // Validate and augment selected items using the order as the authoritative source.
        // The client submits a 0-based position index (never a DB row ID). We reconstruct
        // the same sorted list that fctcr_identify built (order items sorted by their DB id),
        // map each submitted index back to the real order item, validate it belongs to this
        // order, cap qty at the ordered amount, and derive all titles/pricing server-side.
        if (!empty($selectedItems) && $order && !empty($order->order_items)) {
            $taxBehavior = (int)(isset($order->tax_behavior) ? $order->tax_behavior : 0);

            // Must use the exact same sort as ajaxIdentify — shared helper guarantees this.
            $sortedItems = $this->sortedOrderItems($order);

            // Build an index-keyed list that matches the identify response exactly.
            $indexedItems = [];
            foreach ($sortedItems as $orderItem) {
                $label = $this->buildItemLabel($orderItem);
                if ($label === '') {
                    continue; // skipped in identify too — keep indices in sync
                }
                $maxQty = (isset($orderItem->quantity) && is_numeric($orderItem->quantity)) ? max(1, (int)$orderItem->quantity) : 1;
                $indexedItems[] = [
                    'item'    => $orderItem,
                    'title'   => $label,
                    'max_qty' => $maxQty,
                ];
            }

            $validatedItems = [];
            foreach ($selectedItems as $selItem) {
                $idx = $selItem['id']; // 0-based index submitted by the client
                if ($idx < 0 || !isset($indexedItems[$idx])) {
                    continue; // out-of-range or non-existent index — reject
                }
                $entry = $indexedItems[$idx];
                $validatedItems[] = [
                    'order_item_id'      => (isset($entry['item']->id) && is_numeric($entry['item']->id)) ? (int)$entry['item']->id : null,
                    'title'              => $entry['title'],
                    'qty'                => max(1, min($selItem['qty'], $entry['max_qty'])),
                    'unit_price'         => $this->effectiveUnitPrice($entry['item']),
                    'unit_refund_amount' => $this->computeUnitRefundAmount($entry['item'], $taxBehavior),
                ];
            }
            $selectedItems = $validatedItems;

            $estimatedCents = 0;
            foreach ($selectedItems as $sel) {
                if (!empty($sel['unit_refund_amount'])) {
                    $estimatedCents += $sel['unit_refund_amount'] * $sel['qty'];
                }
            }
            if ($estimatedCents > 0) {
                $metaData['estimated_refund']          = $estimatedCents;
                $metaData['estimated_refund_currency'] = !empty($order->currency) ? (string)$order->currency : '';
            }
        }

        if (!empty($selectedItems)) {
            $metaData['selected_items'] = $selectedItems;
        }
        if ($subscriptionTiming !== '') {
            $metaData['subscription_timing'] = $subscriptionTiming;
        }

        $row = $model->create([
            'order_id'        => $orderId ? $orderId : null,
            'customer_id'     => ($order && !empty($order->customer_id)) ? (int)$order->customer_id : null,
            'is_verified'     => (int)$payload['verified'],
            'name'            => $payload['name'],
            'email'           => $payload['email'],
            'order_reference' => $payload['reference'],
            'message'         => $message,
            'source'          => $source,
            'ip_address'      => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '',
            'meta'            => !empty($metaData) ? wp_json_encode($metaData) : null,
        ]);

        if (!$row) {
            wp_send_json_error([
                'message' => __('Something went wrong — please try again.', 'fluent-cart-customer-rights')
            ], 500);
        }

        do_action('fluent_cart/withdrawal_requested', [
            'request' => $row,
            'order'   => $order,
        ]);

        wp_send_json_success($this->formatSubmitted($row));
    }

    /**
     * Admin decision. Only pending requests can transition; records the actor
     * and the GMT timestamp, then fires the status event (decision emails listen).
     *
     * @return object|false The updated row, or false when the transition is invalid.
     */
    public function updateStatus($requestId, $status, $userId)
    {
        if (!in_array($status, ['accepted', 'declined'], true)) {
            return false;
        }

        $model = new RequestModel();
        $row = $model->find($requestId);

        if (!$row || $row->status !== 'pending') {
            return false;
        }

        $model->update($row->id, [
            'status'       => $status,
            'processed_at' => gmdate('Y-m-d H:i:s'),
            'processed_by' => (int)$userId,
        ]);

        $fresh = $model->find($row->id);

        do_action('fluent_cart/withdrawal_request_status_updated', [
            'request'    => $fresh,
            'old_status' => 'pending',
            'new_status' => $status,
            'actor_id'   => (int)$userId,
        ]);

        return $fresh;
    }

    /**
     * Manually links an unverified request to an order (admin queue action).
     *
     * @return object|false
     */
    public function linkOrder($requestId, $orderId)
    {
        if (!class_exists('\FluentCart\App\Models\Order')) {
            return false;
        }

        $model = new RequestModel();
        $row = $model->find($requestId);
        $order = \FluentCart\App\Models\Order::find((int)$orderId);

        if (!$row || !$order) {
            return false;
        }

        $meta = $row->meta ? json_decode($row->meta, true) : [];
        if (!is_array($meta)) {
            $meta = [];
        }
        $meta['linked_manually'] = [
            'by' => get_current_user_id(),
            'at' => gmdate('Y-m-d H:i:s'),
        ];

        // Re-evaluate exclusions now that we know the actual order products.
        $exclusionResult = $this->checkExclusions($order);
        if (!empty($exclusionResult['excluded'])) {
            $meta['excluded_items'] = $exclusionResult['excluded'];
            $meta['all_excluded']   = $exclusionResult['all_excluded'];
        } else {
            unset($meta['excluded_items'], $meta['all_excluded']);
        }

        $model->update($row->id, [
            'order_id'    => (int)$order->id,
            'customer_id' => !empty($order->customer_id) ? (int)$order->customer_id : null,
            'is_verified' => 1,
            'meta'        => wp_json_encode($meta),
        ]);

        return $model->find($row->id);
    }

    /**
     * Builds the display label for an order item: "Product — Variant" when the
     * variant string differs from the product name, falling back to whichever is set.
     */
    private function buildItemLabel($item): string
    {
        $productName = isset($item->post_title) ? trim((string) $item->post_title) : '';
        $variantName = isset($item->title)      ? trim((string) $item->title)      : '';

        if ($productName === '' && $variantName === '') {
            return '';
        }

        if ($variantName !== '' && $variantName !== $productName) {
            return $productName !== '' ? $productName . ' — ' . $variantName : $variantName;
        }

        return $productName !== '' ? $productName : $variantName;
    }

    /**
     * Returns the tax-aware refund amount per unit (cents), after coupon discount.
     *
     * For exclusive-tax lines the per-unit tax from fct_order_items.tax_amount is
     * added on top of the effective (post-discount) unit price. For inclusive or
     * no-tax lines the effective unit price already contains any tax. Per-item
     * line_meta.tax_config.inclusive overrides the order-level tax_behavior to
     * handle mixed inclusive/exclusive orders.
     *
     * fct_order_items.discount_total holds the total coupon/discount amount for the
     * line; dividing by qty gives the per-unit reduction to apply before tax.
     */
    private function computeUnitRefundAmount($item, int $taxBehavior): int
    {
        $qty           = (isset($item->quantity) && is_numeric($item->quantity)) ? max(1, (int) $item->quantity) : 1;
        $unitPrice     = (isset($item->unit_price) && is_numeric($item->unit_price)) ? (int) $item->unit_price : 0;
        $discountTotal = (isset($item->discount_total) && is_numeric($item->discount_total)) ? (int) round((float) $item->discount_total) : 0;
        $itemTax       = (isset($item->tax_amount) && is_numeric($item->tax_amount))
            ? (int) round((float) $item->tax_amount)
            : 0;

        $effectiveUnitPrice = max(0, $unitPrice - (int) round($discountTotal / $qty));

        $lineInclusive = ($taxBehavior === 2);
        if (isset($item->line_meta)) {
            $lineMeta = is_array($item->line_meta)
                ? $item->line_meta
                : json_decode((string) $item->line_meta, true);
            if (is_array($lineMeta) && isset($lineMeta['tax_config']['inclusive'])) {
                $lineInclusive = (bool) $lineMeta['tax_config']['inclusive'];
            }
        }

        if (!$lineInclusive && $itemTax > 0) {
            return $effectiveUnitPrice + (int) round($itemTax / $qty);
        }

        return $effectiveUnitPrice;
    }

    /**
     * Returns the post-discount effective unit price (cents) for an order item.
     * Used in both ajaxIdentify and ajaxSubmit to keep display and snapshot consistent.
     */
    private function effectiveUnitPrice($item): int
    {
        $qty           = (isset($item->quantity) && is_numeric($item->quantity)) ? max(1, (int) $item->quantity) : 1;
        $unitPrice     = (isset($item->unit_price) && is_numeric($item->unit_price)) ? (int) $item->unit_price : 0;
        $discountTotal = (isset($item->discount_total) && is_numeric($item->discount_total)) ? (int) round((float) $item->discount_total) : 0;
        return max(0, $unitPrice - (int) round($discountTotal / $qty));
    }

    private function formatSubmitted($row)
    {
        return [
            'reference'       => strtoupper(substr($row->uuid, 0, 8)),
            'submitted_at'    => get_date_from_gmt($row->submitted_at, get_option('date_format') . ' ' . get_option('time_format')),
            'submitted_date'  => get_date_from_gmt($row->submitted_at, get_option('date_format')),
            'submitted_time'  => get_date_from_gmt($row->submitted_at, get_option('time_format')),
            'email'           => $row->email,
            'name'            => $row->name,
            'order_reference' => $row->order_reference,
        ];
    }

    /**
     * Checks every order item against the configured exclusion lists and returns:
     *   excluded     - titles of items not eligible for withdrawal
     *   all_excluded - true when every countable item is excluded
     */
    public function checkExclusionsPublic($order): array
    {
        return $this->checkExclusions($order);
    }

    private function checkExclusions($order): array
    {
        $excludedTypes       = Settings::getExcludedTypes();
        $excludedCategoryIds = Settings::getExcludedCategories();

        if (empty($excludedTypes) && empty($excludedCategoryIds)) {
            return ['excluded' => [], 'all_excluded' => false];
        }

        $items = isset($order->order_items) ? $order->order_items : [];
        if (empty($items)) {
            return ['excluded' => [], 'all_excluded' => false];
        }

        $taxonomy = Settings::getProductTaxonomy();

        $excludedTitles = [];
        $totalCount = 0;

        foreach ($items as $item) {
            $title = !empty($item->post_title)
                ? $item->post_title
                : (isset($item->title) ? $item->title : '');

            if ($title === '') {
                continue;
            }

            $totalCount++;

            if ($this->isItemExcluded($item, $excludedTypes, $excludedCategoryIds, $taxonomy)) {
                $excludedTitles[] = $title;
            }
        }

        return [
            'excluded'     => array_values(array_unique($excludedTitles)),
            'all_excluded' => $totalCount > 0 && count($excludedTitles) === $totalCount,
        ];
    }

    /**
     * Returns a localised warning string when the order is outside the
     * configured cancellation window, or '' when within window / no restriction.
     * Never hard-blocks — the consumer can still submit; the admin decides.
     */
    private function checkCancellationWindow($order): string
    {
        $periodDays     = Settings::getCancellationPeriodDays();
        $excludeOldDays = Settings::getExcludeOldOrdersDays();

        if (!$periodDays && !$excludeOldDays) {
            return '';
        }

        $now = time();

        if ($periodDays > 0) {
            $refDate = null;
            if (!empty($order->completed_at)) {
                $refDate = strtotime($order->completed_at);
            } elseif (!empty($order->created_at)) {
                $refDate = strtotime($order->created_at);
            }
            if ($refDate && ($now - $refDate) > ($periodDays * DAY_IN_SECONDS)) {
                return __('This order appears to be outside the statutory cancellation period. You can still submit your declaration — the store will review the timing and contact you.', 'fluent-cart-customer-rights');
            }
        }

        if ($excludeOldDays > 0 && !empty($order->created_at)) {
            $orderDate = strtotime($order->created_at);
            if ($orderDate && ($now - $orderDate) > ($excludeOldDays * DAY_IN_SECONDS)) {
                return __('This order appears to be outside the statutory cancellation period. You can still submit your declaration — the store will review the timing and contact you.', 'fluent-cart-customer-rights');
            }
        }

        return '';
    }

    /**
     * Returns true when the order item's product type or category is in the
     * configured exclusion lists. Tries several common field names so the check
     * works across different FluentCart product type conventions.
     */
    private function isItemExcluded($item, array $excludedTypes, array $excludedCategoryIds, string $taxonomy): bool
    {
        if (!empty($excludedTypes)) {
            // Try well-known type fields on the item object itself.
            foreach (['product_type', 'type', 'item_type'] as $field) {
                if (!empty($item->$field) && in_array(trim((string)$item->$field), $excludedTypes, true)) {
                    return true;
                }
            }

            // Fall back to product post meta when a product ID is available.
            $productId = $this->itemProductId($item);
            if ($productId) {
                foreach (['_product_type', '_type', 'product_type'] as $metaKey) {
                    $type = get_post_meta($productId, $metaKey, true);
                    if ($type && in_array(trim((string)$type), $excludedTypes, true)) {
                        return true;
                    }
                }
            }
        }

        if (!empty($excludedCategoryIds) && $taxonomy !== '') {
            $productId = $this->itemProductId($item);
            if ($productId) {
                $termIds = wp_get_object_terms($productId, $taxonomy, ['fields' => 'ids']);
                if (!is_wp_error($termIds)) {
                    foreach ((array)$termIds as $termId) {
                        if (in_array((int)$termId, $excludedCategoryIds, true)) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    /** Returns the per-variant thumbnail URL from fct_product_meta, or '' when none is set. */
    private function variantThumbnail(int $variantId): string
    {
        if (!class_exists('\FluentCart\App\Models\ProductMeta')) {
            return '';
        }
        $meta = \FluentCart\App\Models\ProductMeta::where('object_id', $variantId)
            ->where('object_type', 'product_variant_info')
            ->where('meta_key', 'product_thumbnail')
            ->first();
        if (!$meta || empty($meta->meta_value) || !is_array($meta->meta_value)) {
            return '';
        }
        return (string)($meta->meta_value[0]['url'] ?? '');
    }

    /** Resolves a numeric product post ID from an order item object. */
    private function itemProductId($item): int
    {
        foreach (['post_id', 'product_id', 'variation_id', 'item_id'] as $field) {
            if (!empty($item->$field) && is_numeric($item->$field)) {
                return (int)$item->$field;
            }
        }

        return 0;
    }

    /**
     * Returns order items sorted by their DB row id (ascending) so the 0-based
     * position index assigned in ajaxIdentify is stable when ajaxSubmit rebuilds
     * the list. Both handlers call this method — never inline a sort separately.
     *
     * Items without an id (edge case) sort to the end and preserve their original
     * relative order (stable fallback via the original-position tiebreaker).
     */
    private function sortedOrderItems($order): array
    {
        $raw = is_array($order->order_items)
            ? array_values($order->order_items)
            : array_values(iterator_to_array($order->order_items));

        $keyed = [];
        foreach ($raw as $pos => $item) {
            $keyed[] = [
                'item'    => $item,
                'sort_id' => isset($item->id) && is_numeric($item->id) ? (int)$item->id : PHP_INT_MAX,
                'pos'     => $pos,
            ];
        }

        usort($keyed, function ($a, $b) {
            if ($a['sort_id'] !== $b['sort_id']) {
                return $a['sort_id'] - $b['sort_id'];
            }
            return $a['pos'] - $b['pos']; // stable tiebreaker: preserve original order
        });

        return array_column($keyed, 'item');
    }

    private function guardCommon()
    {
        if (!Settings::isEnabled()) {
            wp_send_json_error([
                'message' => __('The withdrawal function is not available.', 'fluent-cart-customer-rights')
            ], 404);
        }

        if ($this->isRateLimited()) {
            wp_send_json_error([
                'message' => __('Too many attempts — please try again in a few minutes.', 'fluent-cart-customer-rights')
            ], 429);
        }
    }

    private function isRateLimited(): bool
    {
        if (is_user_logged_in()) {
            // Logged-in users are throttled only on failed order matches (probing
            // invoices that don't belong to them). recordUnauthorizedAttempt() increments
            // this counter; guardCommon() checks it.
            $userId    = get_current_user_id();
            $threshold = (int) apply_filters('fctcr/rate_limit/unauthorized_attempts', 5, ['user_id' => $userId]);
            $period    = (int) apply_filters('fctcr/rate_limit/period', self::RATE_PERIOD, ['user_id' => $userId, 'is_logged_in' => true]);
            $count     = (int) get_transient('fctcr_rl_unauth_u' . $userId);
            return $count >= $threshold;
        }

        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
        if (!$ip) {
            return false;
        }

        $limit  = (int) apply_filters('fctcr/rate_limit/guest_attempts', self::RATE_LIMIT, ['ip' => $ip]);
        $period = (int) apply_filters('fctcr/rate_limit/period', self::RATE_PERIOD, ['ip' => $ip, 'is_logged_in' => false]);
        $key    = 'fctcr_rl_' . md5($ip);
        $count  = (int) get_transient($key);
        if ($count >= $limit) {
            return true;
        }
        set_transient($key, $count + 1, $period);
        return false;
    }

    private function recordUnauthorizedAttempt(): void
    {
        if (!is_user_logged_in()) {
            return; // guests are already throttled by the IP counter in isRateLimited()
        }
        $userId = get_current_user_id();
        $period = (int) apply_filters('fctcr/rate_limit/period', self::RATE_PERIOD, ['user_id' => $userId, 'is_logged_in' => true]);
        $key    = 'fctcr_rl_unauth_u' . $userId;
        $count  = (int) get_transient($key);
        set_transient($key, $count + 1, $period);
    }

    /**
     * Matches invoice number + billing email. Both must match the same order;
     * the caller never learns which side failed.
     */
    private function matchOrder($reference, $email)
    {
        if (!class_exists('\FluentCart\App\Models\Order')) {
            return null;
        }

        $ref = ltrim(trim($reference), '#');
        if ($ref === '') {
            return null;
        }

        $order = \FluentCart\App\Models\Order::where('invoice_no', $ref)->orderByDesc('id')->first();

        if (!$order || !$order->customer || empty($order->customer->email)) {
            return null;
        }

        return strtolower($order->customer->email) === strtolower($email) ? $order : null;
    }

    /**
     * Finds the most recent request (any status) for the given typed identity.
     * Used to block re-submission on the unverified path after a decided request.
     *
     * @return object|null
     */
    private function findAnyByIdentity($email, $orderReference)
    {
        if (!class_exists('\FluentCartCustomerRights\WithdrawalRequest')) {
            return null;
        }

        $needle = strtolower(ltrim(trim((string)$orderReference), '#'));

        $candidates = WithdrawalRequest::whereRaw(
            'LOWER(email) = ?',
            [strtolower(trim($email))]
        )->orderByDesc('id')->get();

        foreach ($candidates as $candidate) {
            $ref = strtolower(ltrim(trim((string)$candidate->order_reference), '#'));
            if ($ref === $needle) {
                return $candidate;
            }
        }

        return null;
    }

    private function signToken($payload)
    {
        $data = base64_encode(wp_json_encode($payload));

        return $data . '.' . hash_hmac('sha256', $data, wp_salt('auth'));
    }

    private function verifyToken($token)
    {
        $parts = explode('.', $token);
        if (count($parts) !== 2) {
            return null;
        }

        if (!hash_equals(hash_hmac('sha256', $parts[0], wp_salt('auth')), $parts[1])) {
            return null;
        }

        $payload = json_decode(base64_decode($parts[0]), true);
        if (!is_array($payload) || empty($payload['exp']) || $payload['exp'] < time()) {
            return null;
        }

        return $payload;
    }

    private function formatAmount($cents, $currency)
    {
        return html_entity_decode(
            \FluentCart\App\Helpers\Helper::toDecimal((int)$cents, true, $currency ?: null),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );
    }
}
