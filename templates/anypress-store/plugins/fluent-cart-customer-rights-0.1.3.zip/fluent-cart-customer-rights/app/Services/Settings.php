<?php

namespace FluentCartCustomerRights;

defined('ABSPATH') or die;

class Settings
{
    const MODULE_KEY = 'withdrawal';

    public function register()
    {
        // "Select Withdrawal Page" row in Settings → Store Settings → Pages Setup,
        // alongside the shop/cart/checkout/receipt page selectors.
        add_filter('fluent_cart/store_settings/fields', [$this, 'registerPageField'], 10, 2);
        add_filter('fluent_cart/store_settings/values', [$this, 'registerPageDefault'], 10, 2);
        // Without a sanitizer entry, saveStore() drops unknown keys on save.
        add_filter('fluent_cart/store_settings/sanitizer', [$this, 'registerPageSanitizer']);

        // Makes the Pages Setup "+" create button work for the withdrawal page
        // (core resolves creatable pages from this map — requires the
        // fluent_cart/generatable_pages filter in core).
        add_filter('fluent_cart/generatable_pages', [$this, 'registerGeneratablePage']);

        // If the withdrawal page is the one missing, send the dashboard
        // onboarding warning to our own settings screen instead of core's
        // Pages Setup screen.
        add_filter('fluent_cart/dashboard/page_setup_redirect_url', [$this, 'redirectPageSetupUrl'], 10, 2);

        // Powers the remote category picker in the "Withdrawal" settings page.
        add_filter('fluent_cart/get_dynamic_search_fctcr_categories', [$this, 'searchProductCategories'], 10, 2);

        // Powers the order-status multi-select in the "Withdrawal" settings page.
        add_filter('fluent_cart/get_dynamic_search_fctcr_order_statuses', [$this, 'getOrderStatusOptions'], 10, 2);

        // Powers the shipping-status multi-select in the "Withdrawal" settings page.
        add_filter('fluent_cart/get_dynamic_search_fctcr_shipping_statuses', [$this, 'getShippingStatusOptions'], 10, 2);

        // Injects the settings route and sidebar entry into the SPA via the same
        // PHP-data pattern used by payment_routes / storage_driver_routes.
        add_filter('fluent_cart/admin_app_data', [$this, 'injectAdminAppData']);
    }

    public function injectAdminAppData($data)
    {
        if (!is_array($data)) {
            $data = [];
        }

        $routes = isset($data['addon_settings_routes']) && is_array($data['addon_settings_routes'])
            ? $data['addon_settings_routes']
            : [];

        $routes[] = [
            'name' => 'withdrawal_eu',
            'path' => 'withdrawal-settings',
            'meta' => [
                'active_menu' => 'settings',
                'title'       => __('Withdrawal', 'fluent-cart-customer-rights'),
                'permission'  => 'store/settings',
            ],
        ];

        $data['addon_settings_routes'] = $routes;

        $sidebar = isset($data['addon_settings_sidebar']) && is_array($data['addon_settings_sidebar'])
            ? $data['addon_settings_sidebar']
            : [];

        $sidebar[] = [
            'name'       => __('Withdrawal', 'fluent-cart-customer-rights'),
            'icon'       => 'ShieldCheck',
            'permission' => ['store/settings'],
            'url'        => '/settings/withdrawal-settings',
        ];

        $data['addon_settings_sidebar'] = $sidebar;

        return $data;
    }

    public function registerGeneratablePage($pages)
    {
        if (!is_array($pages)) {
            $pages = [];
        }

        $pages[self::MODULE_KEY] = [
            'title'   => __('Withdraw from contract', 'fluent-cart-customer-rights'),
            'content' => '[fluent_cart_withdrawal]',
        ];

        return $pages;
    }

    public function redirectPageSetupUrl($url, $context)
    {
        $missingPage = is_array($context) ? ($context['missing_page'] ?? []) : [];

        if (($missingPage['key'] ?? null) !== self::MODULE_KEY) {
            return $url;
        }

        $baseUrl = is_array($context) ? ($context['base_url'] ?? '') : '';

        return $baseUrl . 'settings/withdrawal-settings';
    }

    public function getOrderStatusOptions($options, $args)
    {
        return [
            ['value' => 'draft', 'label' => __('Draft', 'fluent-cart-customer-rights')],
            ['value' => 'pending', 'label' => __('Pending', 'fluent-cart-customer-rights')],
            ['value' => 'processing', 'label' => __('Processing', 'fluent-cart-customer-rights')],
            ['value' => 'shipped', 'label' => __('Shipped', 'fluent-cart-customer-rights')],
            ['value' => 'completed', 'label' => __('Completed', 'fluent-cart-customer-rights')],
            ['value' => 'canceled', 'label' => __('Canceled', 'fluent-cart-customer-rights')],
            ['value' => 'refunded', 'label' => __('Refunded', 'fluent-cart-customer-rights')],
            ['value' => 'failed', 'label' => __('Failed', 'fluent-cart-customer-rights')],
        ];
    }

    public function getShippingStatusOptions($options, $args)
    {
        return [
            ['value' => 'unshipped', 'label' => __('Unshipped', 'fluent-cart-customer-rights')],
            ['value' => 'shipped', 'label' => __('Shipped', 'fluent-cart-customer-rights')],
            ['value' => 'delivered', 'label' => __('Delivered', 'fluent-cart-customer-rights')],
            ['value' => 'unshippable', 'label' => __('Unshippable', 'fluent-cart-customer-rights')],
        ];
    }

    public function searchProductCategories($options, $args)
    {
        $search = isset($args['searchBy']) ? sanitize_text_field($args['searchBy']) : '';
        $terms = get_terms([
            'taxonomy'   => self::getProductTaxonomy(),
            'search'     => $search,
            'hide_empty' => false,
            'number'     => 50,
        ]);
        if (is_wp_error($terms)) {
            return $options;
        }
        $result = [];
        foreach ($terms as $term) {
            $result[] = ['value' => $term->term_id, 'label' => $term->name];
        }
        return $result;
    }

    public function registerPageField($fields, $args)
    {
        // Dedicated "Withdrawal" tab for exclusion / taxonomy settings.
        if (isset($fields['setting_tabs']['schema'])) {
            // Pre-populate category options so the multi-select shows labels for already-saved term IDs.
            $storeSettings = get_option('fluent_cart_store_settings', []);
            $savedCatIds = is_array($storeSettings) && !empty($storeSettings['fctcr_excluded_categories'])
                ? array_values(array_filter(array_map('intval', (array)$storeSettings['fctcr_excluded_categories'])))
                : [];
            $preloadedCategoryOptions = [];
            if (!empty($savedCatIds)) {
                $preloadedTerms = get_terms([
                    'taxonomy'   => self::getProductTaxonomy(),
                    'include'    => $savedCatIds,
                    'hide_empty' => false,
                    'number'     => 0,
                ]);
                if (!is_wp_error($preloadedTerms)) {
                    foreach ($preloadedTerms as $term) {
                        $preloadedCategoryOptions[] = ['value' => $term->term_id, 'label' => $term->name];
                    }
                }
            }

            $fields['setting_tabs']['schema']['withdrawal_eu'] = [
                'title'           => __('Withdrawal', 'fluent-cart-customer-rights'),
                'show_title'      => false,
                'type'            => 'section',
                'disable_nesting' => true,
                'columns'         => [
                    'default' => 1,
                    'md'      => 1
                ],
                'schema'          => [

                    // ── Button Placement ─────────────────────────────────────
                    'fctcr_heading_visibility' => [
                        'type'  => 'html',
                        'value' => '<div style="font-weight:600;font-size:13px;margin-bottom:2px;">'
                            . esc_html__('Button Placement', 'fluent-cart-customer-rights')
                            . '</div>'
                            . '<div class="form-note" style="margin-bottom:8px;">'
                            . esc_html__('Controls where the "Withdraw from contract" link appears in the customer portal. When a request is open or decided, a status label is shown instead.', 'fluent-cart-customer-rights')
                            . '</div>',
                    ],
                    'fctcr_toggles_visibility' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 1],
                        'disable_nesting' => true,
                        'schema'          => [

                            'fctcr_show_in_subscription_grid' => [
                                'type'            => 'grid',
                                'disable_nesting' => true,
                                'columns'         => ['default' => 1, 'md' => 3],
                                'schema'          => [
                                    'label' => [
                                        'type'  => 'html',
                                        'value' => __('Show in subscription detail', 'fluent-cart-customer-rights'),
                                    ],
                                    'fctcr_show_in_subscription' => [
                                        'type'       => 'switch',
                                        'value'      => 'yes',
                                        'attributes' => ['active-value' => 'yes', 'inactive-value' => 'no'],
                                    ],
                                ],
                            ],

                            'fctcr_show_in_order_grid' => [
                                'type'            => 'grid',
                                'disable_nesting' => true,
                                'columns'         => ['default' => 1, 'md' => 3],
                                'schema'          => [
                                    'label' => [
                                        'type'  => 'html',
                                        'value' => __('Show in order detail', 'fluent-cart-customer-rights'),
                                    ],
                                    'fctcr_show_in_order' => [
                                        'type'       => 'switch',
                                        'value'      => 'yes',
                                        'attributes' => ['active-value' => 'yes', 'inactive-value' => 'no'],
                                    ],
                                ],
                            ],

                            'fctcr_show_in_dashboard_grid' => [
                                'type'            => 'grid',
                                'disable_nesting' => true,
                                'columns'         => ['default' => 1, 'md' => 3],
                                'schema'          => [
                                    'label' => [
                                        'type'  => 'html',
                                        'value' => __('Show in customer dashboard', 'fluent-cart-customer-rights'),
                                    ],
                                    'fctcr_show_in_dashboard' => [
                                        'type'       => 'switch',
                                        'value'      => 'yes',
                                        'attributes' => ['active-value' => 'yes', 'inactive-value' => 'no'],
                                    ],
                                ],
                            ],

                        ],
                    ],

                    'fctcr_hr_vis_form'  => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    // ── Form Behaviour ───────────────────────────────────────
                    'fctcr_heading_form' => [
                        'type'  => 'html',
                        'value' => '<div style="font-weight:600;font-size:13px;">'
                            . esc_html__('Form Behaviour', 'fluent-cart-customer-rights')
                            . '</div>',
                    ],

                    'fctcr_verified_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'fctcr_verified_label' => [
                                'type'  => 'html',
                                'value' => '<span class="setting-label">' . __('Require a verified order match', 'fluent-cart-customer-rights') . '</span>',
                            ],
                            'fctcr_require_verified_match' => [
                                'wrapperClass' => 'col-span-2 flex items-start',
                                'type'         => 'switch',
                                'value'        => 'no',
                                'attributes'   => ['active-value' => 'yes', 'inactive-value' => 'no'],
                            ],
                            'fctcr_verified_note' => [
                                'wrapperClass' => 'col-span-full',
                                'type'         => 'html',
                                'value'        => '<div class="form-note">' . __('When off (recommended), unmatched declarations are still queued as unverified — § 356a BGB never refuses a withdrawal. Only enable if your operations require a matched order before processing.', 'fluent-cart-customer-rights') . '</div>',
                            ],
                        ],
                    ],

                    'hr' => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    'fctcr_comment_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'fctcr_comment_label' => [
                                'type'  => 'html',
                                'value' => '<span class="setting-label">' . __('Show the optional note field', 'fluent-cart-customer-rights') . '</span>',
                            ],
                            'fctcr_show_comment_field' => [
                                'wrapperClass' => 'col-span-2 flex items-start',
                                'type'         => 'switch',
                                'value'        => 'yes',
                                'attributes'   => ['active-value' => 'yes', 'inactive-value' => 'no'],
                            ],
                            'fctcr_comment_note' => [
                                'wrapperClass' => 'col-span-full',
                                'type'         => 'html',
                                'value'        => '<div class="form-note">' . __('Lets the customer add an optional free-text note to their declaration. Item scope is handled by the item selection step — this field is for any additional context.', 'fluent-cart-customer-rights') . '</div>',
                            ],
                        ],
                    ],

                    'hr1' => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    'fctcr_partial_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'fctcr_partial_label' => [
                                'type'  => 'html',
                                'value' => '<span class="setting-label">' . __('Allow partial revocations', 'fluent-cart-customer-rights') . '</span>',
                            ],
                            'fctcr_partial_revocations_permitted' => [
                                'wrapperClass' => 'col-span-2 flex items-start',
                                'type'         => 'switch',
                                'value'        => 'yes',
                                'attributes'   => ['active-value' => 'yes', 'inactive-value' => 'no'],
                            ],
                            'fctcr_partial_note' => [
                                'wrapperClass' => 'col-span-full',
                                'type'         => 'html',
                                'value'        => '<div class="form-note">' . __('When off, all withdrawals are treated as full-contract withdrawals. The note field is hidden regardless of the toggle above.', 'fluent-cart-customer-rights') . '</div>',
                            ],
                        ],
                    ],

                    'fctcr_hr_form_item'               => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    // ── Item Selection Step ──────────────────────────────────
                    'fctcr_item_step_eligibility_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'label'                       => [
                                'type'  => 'html',
                                'value' => sprintf(
                                    '<span class="setting-label">%1$s</span>',
                                    __('Item selection step — who can use it', 'fluent-cart-customer-rights')
                                ),
                            ],
                            'fctcr_item_step_eligibility' => [
                                'wrapperClass' => 'col-span-2',
                                'label'        => '',
                                'type'         => 'select',
                                'value'        => 'account_owner',
                                'options'      => [
                                    ['value' => 'account_owner', 'label' => __('Account owner (logged in, email + invoice match)', 'fluent-cart-customer-rights')],
                                    ['value' => 'email_verified', 'label' => __('Email-verified submitter (invoice + email match)', 'fluent-cart-customer-rights')],
                                ],
                                'note' => __('Controls which customers see the line-item selection step (step 1b). "Account owner" requires the customer to be logged in with the account that placed the order. "Email-verified" shows the step to any submitter who correctly matches invoice number + billing email, including guests.', 'fluent-cart-customer-rights')
                            ],
                        ],
                    ],

                    'fctcr_hr0'                => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    // ── Email Notifications ──────────────────────────────────
                    'fctcr_notifications_link' => [
                        'type'  => 'html',
                        'value' => sprintf(
                            '<div class="el-alert el-alert--info is-light" style="padding:10px 16px;margin-bottom:0;"><p style="margin:0;">%s <a href="%s">%s</a></p></div>',
                            esc_html__('Withdrawal email notifications (acknowledgment, accepted, declined) are configured in', 'fluent-cart-customer-rights'),
                            esc_url(admin_url('admin.php?page=fluent-cart#/settings/email_notifications#withdrawal')),
                            esc_html__('Email Configuration → Notifications', 'fluent-cart-customer-rights')
                        ),
                    ],

                    'fctcr_hr1'          => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    // ── Time Windows ─────────────────────────────────────────
                    'fctcr_heading_time' => [
                        'type'  => 'html',
                        'value' => '<div style="font-weight:600;font-size:13px;margin-bottom:8px;">'
                            . esc_html__('Time Windows', 'fluent-cart-customer-rights')
                            . '</div>',
                    ],

                    'fctcr_period_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'label'                          => [
                                'type'  => 'html',
                                'value' => sprintf(
                                    '<span class="setting-label">%1$s</span><div class="form-note">%2$s</div>',
                                    __('Statutory cancellation period (days)', 'fluent-cart-customer-rights'),
                                    __('Maximum age of an order (based on completion date) eligible for withdrawal. 0 means no restriction. Out-of-window orders show a warning — declarations are never hard-blocked.', 'fluent-cart-customer-rights')
                                ),
                            ],
                            'fctcr_cancellation_period_days' => [
                                'wrapperClass' => 'col-span-2',
                                'label'        => '',
                                'type'         => 'text',
                                'data-type'    => 'number',
                                'value'        => 0,
                                'placeholder'  => '0',
                            ],
                        ],
                    ],

                    'fctcr_old_days_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'label'                         => [
                                'type'  => 'html',
                                'value' => sprintf(
                                    '<span class="setting-label">%1$s</span><div class="form-note">%2$s</div>',
                                    __('Exclude orders older than (days)', 'fluent-cart-customer-rights'),
                                    __('Fallback age check using the order creation date — useful when orders are never marked Completed. 0 means no restriction.', 'fluent-cart-customer-rights')
                                ),
                            ],
                            'fctcr_exclude_old_orders_days' => [
                                'wrapperClass' => 'col-span-2',
                                'label'        => '',
                                'type'         => 'text',
                                'data-type'    => 'number',
                                'value'        => 0,
                                'placeholder'  => '0',
                            ],
                        ],
                    ],

                    'fctcr_hr2'               => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    // ── Order Filtering ──────────────────────────────────────
                    'fctcr_heading_filtering' => [
                        'type'  => 'html',
                        'value' => '<div style="font-weight:600;font-size:13px;margin-bottom:8px;">'
                            . esc_html__('Order Filtering', 'fluent-cart-customer-rights')
                            . '</div>',
                    ],

                    'fctcr_statuses_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'label'                        => [
                                'type'  => 'html',
                                'value' => sprintf(
                                    '<span class="setting-label">%1$s</span><div class="form-note">%2$s</div>',
                                    __('Blocked order statuses', 'fluent-cart-customer-rights'),
                                    __('Orders in these statuses are rejected at step 1 and the withdrawal button is hidden in the customer portal — withdrawing against a cancelled or failed order is operationally meaningless.', 'fluent-cart-customer-rights')
                                ),
                            ],
                            'fctcr_blocked_order_statuses' => [
                                'wrapperClass' => 'col-span-2',
                                'label'        => '',
                                'type'         => 'remote_select',
                                'remote_key'   => 'fctcr_order_statuses',
                                'multiple'     => true,
                                'value'        => ['canceled', 'failed', 'draft', 'completed'],
                                'options'      => $this->getOrderStatusOptions([], []),
                            ],
                        ],
                    ],
                    'fctcr_hr'       => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],
                    'fctcr_shipping_statuses_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'label'                           => [
                                'type'  => 'html',
                                'value' => sprintf(
                                    '<span class="setting-label">%1$s</span><div class="form-note">%2$s</div>',
                                    __('Blocked shipping statuses', 'fluent-cart-customer-rights'),
                                    __('Orders whose shipping status matches one of these values are rejected at step 1 and the withdrawal button is hidden — shipping status is stored separately from order status.', 'fluent-cart-customer-rights')
                                ),
                            ],
                            'fctcr_blocked_shipping_statuses' => [
                                'wrapperClass' => 'col-span-2',
                                'label'        => '',
                                'type'         => 'remote_select',
                                'remote_key'   => 'fctcr_shipping_statuses',
                                'multiple'     => true,
                                'value'        => ['shipped'],
                                'options'      => $this->getShippingStatusOptions([], []),
                            ],
                        ],
                    ],

                    'fctcr_hr3'       => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    // ── Art. 16 CRD Exclusions ───────────────────────────────
                    'fctcr_cats_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'label'                     => [
                                'type'  => 'html',
                                'value' => sprintf(
                                    '<span class="setting-label">%1$s</span><div class="form-note">%2$s</div>',
                                    __('Excluded product categories', 'fluent-cart-customer-rights'),
                                    __('Product categories not eligible for withdrawal under Art. 16 CRD (e.g. digital goods, perishables). When all items in an order are excluded the customer sees a warning but can still submit — the declaration is never refused.', 'fluent-cart-customer-rights')
                                ),
                            ],
                            'fctcr_excluded_categories' => [
                                'wrapperClass' => 'col-span-2',
                                'label'        => '',
                                'type'         => 'remote_select',
                                'remote_key'   => 'fctcr_categories',
                                'multiple'     => true,
                                'value'        => [],
                                'options'      => $preloadedCategoryOptions,
                            ],
                        ],
                    ],

                    'fctcr_hr4'            => [
                        'type'  => 'html',
                        'value' => '<hr class="settings-divider">',
                    ],

                    // ── Withdrawal Page ──────────────────────────────────────
                    'withdrawal_page_grid' => [
                        'type'            => 'grid',
                        'columns'         => ['default' => 1, 'md' => 3],
                        'disable_nesting' => true,
                        'schema'          => [
                            'label'              => [
                                'type'  => 'html',
                                'value' => sprintf(
                                    '<span class="setting-label">%1$s</span><div class="form-note">%2$s</div>',
                                    __('Select Withdrawal Page', 'fluent-cart-customer-rights'),
                                    __('The WordPress page that hosts [fluent_cart_withdrawal]. Link it prominently — e.g. as a footer link — so it is easily accessible to customers (§ 356a BGB).', 'fluent-cart-customer-rights')
                                ),
                            ],
                            'withdrawal_page_id' => [
                                'wrapperClass' => 'col-span-2',
                                'label'        => false,
                                'page_title'   => __('Withdraw from contract', 'fluent-cart-customer-rights'),
                                'type'         => 'component',
                                'component'    => 'StoreSettings/PageSelector',
                                'page_key'     => 'withdrawal_page_id',
                                'preview_link' => self::getPageUrl(),
                                'hide_note'    => true,
                                'options'      => \FluentCart\App\CPT\Pages::getPages(''),
                                'value'        => '',
                                'note'         => \FluentCart\App\Helpers\Helper::getShortcodeInstructionString(
                                    '[fluent_cart_withdrawal]',
                                    __('Withdraw from contract', 'fluent-cart-customer-rights')
                                ),
                            ],
                        ],
                    ],

                ],
            ];
        }

        return $fields;
    }

    public function registerPageDefault($values, $args)
    {
        if (!isset($values['withdrawal_page_id'])) {
            $values['withdrawal_page_id'] = '';
        }
        if (!isset($values['fctcr_show_in_subscription'])) {
            $values['fctcr_show_in_subscription'] = 'yes';
        }
        if (!isset($values['fctcr_show_in_order'])) {
            $values['fctcr_show_in_order'] = 'yes';
        }
        if (!isset($values['fctcr_show_in_dashboard'])) {
            $values['fctcr_show_in_dashboard'] = 'yes';
        }
        if (!isset($values['fctcr_require_verified_match'])) {
            $values['fctcr_require_verified_match'] = 'no';
        }
        if (!isset($values['fctcr_admin_notification_email'])) {
            $values['fctcr_admin_notification_email'] = '';
        }
        if (!isset($values['fctcr_cancellation_period_days'])) {
            $values['fctcr_cancellation_period_days'] = 0;
        }
        if (!isset($values['fctcr_exclude_old_orders_days'])) {
            $values['fctcr_exclude_old_orders_days'] = 0;
        }
        if (!isset($values['fctcr_blocked_order_statuses'])) {
            $values['fctcr_blocked_order_statuses'] = ['canceled', 'failed', 'draft', 'completed'];
        }
        if (!isset($values['fctcr_blocked_shipping_statuses'])) {
            $values['fctcr_blocked_shipping_statuses'] = ['shipped'];
        }
        if (!isset($values['fctcr_show_comment_field'])) {
            $values['fctcr_show_comment_field'] = 'yes';
        }
        if (!isset($values['fctcr_partial_revocations_permitted'])) {
            $values['fctcr_partial_revocations_permitted'] = 'yes';
        }
        if (!isset($values['fctcr_excluded_types'])) {
            $values['fctcr_excluded_types'] = '';
        }
        if (!isset($values['fctcr_excluded_categories'])) {
            $values['fctcr_excluded_categories'] = [];
        }
        if (!isset($values['fctcr_product_taxonomy'])) {
            $values['fctcr_product_taxonomy'] = '';
        }
        if (!isset($values['fctcr_item_step_eligibility'])) {
            $values['fctcr_item_step_eligibility'] = 'account_owner';
        }

        return $values;
    }

    public function registerPageSanitizer($sanitizer)
    {
        $sanitizer['withdrawal_page_id'] = 'intval';
        $sanitizer['fctcr_admin_notification_email'] = 'sanitize_email';
        $sanitizer['fctcr_cancellation_period_days'] = 'intval';
        $sanitizer['fctcr_exclude_old_orders_days'] = 'intval';
        $sanitizer['fctcr_blocked_order_statuses'] = static function ($value) {
            return array_values(array_filter(array_map('sanitize_key', (array)$value)));
        };
        $sanitizer['fctcr_blocked_shipping_statuses'] = static function ($value) {
            return array_values(array_filter(array_map('sanitize_key', (array)$value)));
        };
        $sanitizer['fctcr_show_comment_field'] = 'sanitize_text_field';
        $sanitizer['fctcr_partial_revocations_permitted'] = 'sanitize_text_field';
        $sanitizer['fctcr_show_in_subscription'] = 'sanitize_text_field';
        $sanitizer['fctcr_show_in_order'] = 'sanitize_text_field';
        $sanitizer['fctcr_show_in_dashboard'] = 'sanitize_text_field';
        $sanitizer['fctcr_require_verified_match'] = 'sanitize_text_field';
        $sanitizer['fctcr_excluded_types'] = 'sanitize_text_field';
        $sanitizer['fctcr_excluded_categories'] = static function ($value) {
            return array_values(array_filter(array_map('intval', (array)$value)));
        };
        $sanitizer['fctcr_product_taxonomy'] = 'sanitize_text_field';
        $sanitizer['fctcr_item_step_eligibility'] = static function ($value) {
            return in_array($value, ['account_owner', 'email_verified'], true) ? $value : 'account_owner';
        };

        return $sanitizer;
    }

    public static function isEnabled()
    {
        return true;
    }

    /**
     * @param string $key Sub-setting key, e.g. 'require_verified_match'
     * @param mixed $default
     * @return mixed
     */
    public static function get($key, $default = null)
    {
        $settings = self::all();

        return isset($settings[$key]) ? $settings[$key] : $default;
    }

    private static function all()
    {
        $store = get_option('fluent_cart_store_settings', []);
        if (!is_array($store)) {
            $store = [];
        }

        return [
            'show_in_subscription'   => isset($store['fctcr_show_in_subscription']) ? $store['fctcr_show_in_subscription'] : 'yes',
            'show_in_order'          => isset($store['fctcr_show_in_order']) ? $store['fctcr_show_in_order'] : 'yes',
            'show_in_dashboard'      => isset($store['fctcr_show_in_dashboard']) ? $store['fctcr_show_in_dashboard'] : 'yes',
            'require_verified_match' => isset($store['fctcr_require_verified_match']) ? $store['fctcr_require_verified_match'] : 'no',
        ];
    }

    /**
     * Returns product type slugs (e.g. 'digital', 'subscription') that are not
     * eligible for withdrawal under Art. 16 CRD. Configurable via the
     * "Withdrawal" tab in Store Settings or the
     * fluent_cart_resolution/excluded_product_types filter.
     *
     * @return string[]
     */
    public static function getExcludedTypes(): array
    {
        $store = get_option('fluent_cart_store_settings', []);
        $raw = is_array($store) && isset($store['fctcr_excluded_types']) ? $store['fctcr_excluded_types'] : '';
        $types = array_values(array_filter(array_map('trim', explode(',', (string)$raw))));

        return apply_filters('fluent_cart_resolution/excluded_product_types', $types, ['raw_value' => $raw]);
    }

    /**
     * Returns term IDs for product categories not eligible for withdrawal.
     * Configurable via the "Withdrawal" settings page or the
     * fluent_cart_resolution/excluded_product_categories filter.
     *
     * @return int[]
     */
    public static function getExcludedCategories(): array
    {
        $store = get_option('fluent_cart_store_settings', []);
        $saved = is_array($store) && isset($store['fctcr_excluded_categories'])
            ? $store['fctcr_excluded_categories']
            : [];
        $ids = array_values(array_filter(array_map('intval', (array)$saved)));

        return apply_filters('fluent_cart_resolution/excluded_product_categories', $ids, ['raw_ids' => $saved]);
    }

    /**
     * Returns the WordPress taxonomy slug used for product categories.
     * Defaults to 'product-categories' (FluentCart's registered taxonomy slug).
     * Configurable via the "Withdrawal" settings page or the
     * fluent_cart_resolution/product_taxonomy filter.
     *
     * @return string
     */
    public static function getProductTaxonomy(): string
    {
        $store = get_option('fluent_cart_store_settings', []);
        $taxonomy = is_array($store) && !empty($store['fctcr_product_taxonomy'])
            ? sanitize_key($store['fctcr_product_taxonomy'])
            : 'product-categories';

        return (string)apply_filters('fluent_cart_resolution/product_taxonomy', $taxonomy, ['raw_value' => is_array($store) && isset($store['fctcr_product_taxonomy']) ? $store['fctcr_product_taxonomy'] : '']);
    }

    /**
     * The page ID is stored in fluent_cart_store_settings['withdrawal_page_id']
     * by the Pages Setup tab. Reads the raw option to bypass core's static cache.
     */
    public static function getPageId()
    {
        $store = get_option('fluent_cart_store_settings', []);
        $pageId = is_array($store) ? (int)(isset($store['withdrawal_page_id']) ? $store['withdrawal_page_id'] : 0) : 0;

        if (!$pageId) {
            return 0;
        }

        $page = get_post($pageId);
        if (!$page || $page->post_status === 'trash') {
            return 0;
        }

        return $pageId;
    }

    public static function getPageUrl()
    {
        $pageId = self::getPageId();

        return $pageId ? get_permalink($pageId) : '';
    }

    /**
     * The dedicated email address for admin withdrawal notifications.
     * Falls back to FluentCart's configured admin email when blank.
     */
    public static function getAdminNotificationEmail(): string
    {
        $store = get_option('fluent_cart_store_settings', []);
        $email = is_array($store) && !empty($store['fctcr_admin_notification_email'])
            ? $store['fctcr_admin_notification_email']
            : '';

        return sanitize_email($email);
    }

    /**
     * Maximum order age (days since completion) eligible for withdrawal.
     * 0 = no restriction.
     */
    public static function getCancellationPeriodDays(): int
    {
        $store = get_option('fluent_cart_store_settings', []);

        return is_array($store) && isset($store['fctcr_cancellation_period_days'])
            ? max(0, (int)$store['fctcr_cancellation_period_days'])
            : 0;
    }

    /**
     * Fallback age check using order creation date (for stores that never
     * mark orders Completed). 0 = no restriction.
     */
    public static function getExcludeOldOrdersDays(): int
    {
        $store = get_option('fluent_cart_store_settings', []);

        return is_array($store) && isset($store['fctcr_exclude_old_orders_days'])
            ? max(0, (int)$store['fctcr_exclude_old_orders_days'])
            : 0;
    }

    /**
     * Order statuses that block a withdrawal at step 1.
     * Defaults to cancelled/failed/draft when not yet saved.
     */
    public static function getBlockedOrderStatuses(): array
    {
        $store = get_option('fluent_cart_store_settings', []);

        if (!is_array($store) || !array_key_exists('fctcr_blocked_order_statuses', $store)) {
            return ['canceled', 'failed', 'draft', 'completed'];
        }

        return array_values(array_filter(array_map('sanitize_key', (array)$store['fctcr_blocked_order_statuses'])));
    }

    /**
     * Shipping statuses that block a withdrawal at step 1.
     * Defaults to ['shipped'] when not yet saved.
     */
    public static function getBlockedShippingStatuses(): array
    {
        $store = get_option('fluent_cart_store_settings', []);

        if (!is_array($store) || !array_key_exists('fctcr_blocked_shipping_statuses', $store)) {
            return ['shipped'];
        }

        return array_values(array_filter(array_map('sanitize_key', (array)$store['fctcr_blocked_shipping_statuses'])));
    }

    public static function getRequiredFields(): array
    {
        $all = ['first_name', 'last_name', 'order_number', 'email'];
        return (array)apply_filters('fctcr/required_fields', $all, ['default_fields' => $all]);
    }

    public static function getShowCommentField(): bool
    {
        $store = get_option('fluent_cart_store_settings', []);
        $val = is_array($store) && isset($store['fctcr_show_comment_field'])
            ? $store['fctcr_show_comment_field']
            : 'yes';
        return $val === 'yes';
    }

    public static function getPartialRevocationsPermitted(): bool
    {
        $store = get_option('fluent_cart_store_settings', []);
        $val = is_array($store) && isset($store['fctcr_partial_revocations_permitted'])
            ? $store['fctcr_partial_revocations_permitted']
            : 'yes';
        return $val === 'yes';
    }

    /**
     * Controls who qualifies to see the item-selection step (step 1b).
     *
     * 'account_owner' — the logged-in user's WP account must match the order's customer.
     * 'email_verified' — any submitter who correctly matched invoice number + email.
     */
    public static function getItemStepEligibility(): string
    {
        $store = get_option('fluent_cart_store_settings', []);
        $value = is_array($store) && isset($store['fctcr_item_step_eligibility'])
            ? $store['fctcr_item_step_eligibility']
            : 'account_owner';

        return in_array($value, ['account_owner', 'email_verified'], true) ? $value : 'account_owner';
    }


}
