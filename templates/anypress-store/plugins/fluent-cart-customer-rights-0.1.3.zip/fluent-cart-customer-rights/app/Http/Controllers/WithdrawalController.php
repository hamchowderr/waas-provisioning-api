<?php

namespace FluentCartCustomerRights;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\Framework\Http\Request\Request;

defined('ABSPATH') or die;

class WithdrawalController extends Controller
{
    public function index(Request $request)
    {
        // Standard list pipeline: RequestFilter (BaseFilter) handles search,
        // tabs (active_view), sorting, advanced filters, and pagination.
        $requests = RequestFilter::fromRequest($request)->paginate();

        $dateFormat = get_option('date_format') . ' ' . get_option('time_format');

        foreach ($requests as $row) {
            $row->reference = strtoupper(substr($row->uuid, 0, 8));
            $row->received_at = $row->submitted_at ? get_date_from_gmt($row->submitted_at, $dateFormat) : null;
            $row->processed_at_formatted = $row->processed_at ? get_date_from_gmt($row->processed_at, $dateFormat) : null;
            $exclusions = $this->parseExclusions($row);
            $row->excluded_items = $exclusions['excluded_items'];
            $row->exclusion_badge = $exclusions['exclusion_badge'];
            $row->selected_items = $this->parseSelectedItems($row);
            $refundData = $this->parseEstimatedRefund($row);
            $row->estimated_refund = $refundData['estimated_refund'];
            $row->estimated_refund_currency = $refundData['estimated_refund_currency'];
            $row->auth_mode = $this->parseAuthMode($row);
        }

        return $this->sendSuccess([
            'withdrawal_requests' => $requests,
        ]);
    }

    public function updateStatus(Request $request, $id)
    {
        $status = $request->getSafe('status', 'sanitize_text_field');

        $result = (new WithdrawalService())->updateStatus((int)$id, $status, get_current_user_id());

        if (!$result) {
            return $this->sendError([
                'message' => __('That action could not be completed — the request may already be decided.', 'fluent-cart-customer-rights')
            ], 422);
        }

        return $this->sendSuccess([
            'request' => $this->formatRow($result),
            'message' => __('The withdrawal request has been updated.', 'fluent-cart-customer-rights')
        ]);
    }

    public function linkOrder(Request $request, $id)
    {
        $orderId = (int)$request->getSafe('order_id', 'absint');

        $result = (new WithdrawalService())->linkOrder((int)$id, $orderId);

        if (!$result) {
            return $this->sendError([
                'message' => __('That order could not be linked — please check the order ID.', 'fluent-cart-customer-rights')
            ], 422);
        }

        return $this->sendSuccess([
            'request' => $this->formatRow($result),
            'message' => __('The request is now linked to the order.', 'fluent-cart-customer-rights')
        ]);
    }

    private function formatRow($row)
    {
        $exclusions = $this->parseExclusions($row);
        $refundData = $this->parseEstimatedRefund($row);

        return [
            'id'                         => (int)$row->id,
            'reference'                  => strtoupper(substr($row->uuid, 0, 8)),
            'name'                       => $row->name,
            'email'                      => $row->email,
            'order_id'                   => $row->order_id ? (int)$row->order_id : null,
            'order_reference'            => $row->order_reference,
            'message'                    => $row->message,
            'source'                     => $row->source,
            'is_verified'                => (bool)$row->is_verified,
            'status'                     => $row->status,
            'received_at'                => get_date_from_gmt($row->submitted_at, get_option('date_format') . ' ' . get_option('time_format')),
            'processed_at'               => $row->processed_at ? get_date_from_gmt($row->processed_at, get_option('date_format') . ' ' . get_option('time_format')) : null,
            'excluded_items'             => $exclusions['excluded_items'],
            'exclusion_badge'            => $exclusions['exclusion_badge'],
            'selected_items'             => $this->parseSelectedItems($row),
            'estimated_refund'           => $refundData['estimated_refund'],
            'estimated_refund_currency'  => $refundData['estimated_refund_currency'],
            'auth_mode'                  => $this->parseAuthMode($row),
        ];
    }

    private function parseSelectedItems($row)
    {
        $meta = ($row->meta && is_string($row->meta)) ? json_decode($row->meta, true) : [];
        if (!is_array($meta)) {
            $meta = [];
        }
        return !empty($meta['selected_items']) && is_array($meta['selected_items']) ? $meta['selected_items'] : [];
    }

    private function parseEstimatedRefund($row): array
    {
        $meta = ($row->meta && is_string($row->meta)) ? json_decode($row->meta, true) : [];
        if (!is_array($meta)) {
            $meta = [];
        }
        return [
            'estimated_refund'          => isset($meta['estimated_refund']) ? (int) $meta['estimated_refund'] : null,
            'estimated_refund_currency' => isset($meta['estimated_refund_currency']) ? (string) $meta['estimated_refund_currency'] : '',
        ];
    }

    private function parseAuthMode($row): string
    {
        $meta = ($row->meta && is_string($row->meta)) ? json_decode($row->meta, true) : [];
        if (!is_array($meta)) {
            $meta = [];
        }
        return isset($meta['auth_mode']) ? (string)$meta['auth_mode'] : 'unverified';
    }

    private function parseExclusions($row)
    {
        $meta = ($row->meta && is_string($row->meta)) ? json_decode($row->meta, true) : [];
        if (!is_array($meta)) {
            $meta = [];
        }
        $items = !empty($meta['excluded_items']) && is_array($meta['excluded_items']) ? $meta['excluded_items'] : [];

        return [
            'excluded_items'  => $items,
            'exclusion_badge' => empty($items) ? null : (!empty($meta['all_excluded']) ? 'all' : 'partial'),
        ];
    }
}
