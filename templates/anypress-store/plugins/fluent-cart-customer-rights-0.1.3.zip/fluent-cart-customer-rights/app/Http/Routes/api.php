<?php

defined('ABSPATH') or die;

/**
 * @var $router \FluentCart\Framework\Http\Router
 */

use FluentCartCustomerRights\WithdrawalController;

$router->prefix('withdrawal-requests')
    ->withPolicy('\FluentCart\App\Http\Policies\OrderPolicy')
    ->group(function ($router) {
        $router->get('/', [WithdrawalController::class, 'index'])->meta([
            'permissions' => 'orders/view'
        ]);
        $router->post('/{id}/status', [WithdrawalController::class, 'updateStatus'])->int('id')->meta([
            'permissions' => 'orders/manage'
        ]);
        $router->post('/{id}/link-order', [WithdrawalController::class, 'linkOrder'])->int('id')->meta([
            'permissions' => 'orders/manage'
        ]);
    });
