<?php
/*
Plugin Name: FluentCart Customer Rights
Description: EU/German digital withdrawal function (Widerrufsbutton, § 356a BGB) add-on for FluentCart — mandatory for German B2C stores from June 19, 2026.
Version: 0.1.3
Author: FluentCart Team
Author URI: https://fluentcart.com/about-us
Plugin URI: https://fluentcart.com
License: GPLv2 or later
Text Domain: fluent-cart-customer-rights
Domain Path: /language
*/

defined('ABSPATH') or die;

if (defined('FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH')) {
    return;
}

define('FLUENT_CART_CUSTOMER_RIGHTS_VERSION', '0.1.3');
define('FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('FLUENT_CART_CUSTOMER_RIGHTS_URL', plugin_dir_url(__FILE__));
define('FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_FILE_PATH', __FILE__);

class FluentCartCustomerRights
{
    public static function init()
    {
        register_activation_hook(FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_FILE_PATH, [__CLASS__, 'onActivation']);

        add_action('plugins_loaded', [__CLASS__, 'onPluginsLoaded'], 20);
    }

    public static function onActivation()
    {
        if (!defined('FLUENTCART_PLUGIN_PATH')) {
            return;
        }

        (new static())->handleDbMigration();
    }

    public static function onPluginsLoaded()
    {
        load_plugin_textdomain(
            'fluent-cart-customer-rights',
            false,
            dirname(plugin_basename(FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_FILE_PATH)) . '/language'
        );

        (new static())->initUpdater();

        if (!defined('FLUENTCART_PLUGIN_PATH')) {
            add_action('admin_notices', function () {
                ?>
                <div class="notice notice-error">
                    <p>
                        <strong><?php esc_html_e('FluentCart Customer Rights', 'fluent-cart-customer-rights'); ?></strong>
                        <?php esc_html_e('requires FluentCart to be installed and activated.', 'fluent-cart-customer-rights'); ?>
                    </p>
                </div>
                <?php
            });
            return;
        }

        (new static())->boot(fluentCart());
    }

    public function boot($app)
    {
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Models/RequestModel.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Models/WithdrawalRequest.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Services/Settings.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Services/Renderer.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Services/RequestFilter.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Services/WithdrawalService.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Hooks/Handlers/Emails.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Hooks/Handlers/Shortcode.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Hooks/Handlers/CustomerProfile.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Hooks/Handlers/AdminPage.php';
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Http/Controllers/WithdrawalController.php';

        if (defined('WP_CLI') && WP_CLI) {
            $cliFile = FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Hooks/CLI/Commands.php';
            if (file_exists($cliFile)) {
                require_once $cliFile;
                \WP_CLI::add_command('fctcr', '\FluentCartCustomerRights\CLI\Commands');
            }
        }

        (new \FluentCartCustomerRights\Settings())->register();
        (new \FluentCartCustomerRights\CustomerProfile())->register();
        (new \FluentCartCustomerRights\WithdrawalService())->registerAjax();
        (new \FluentCartCustomerRights\Emails())->register();
        (new \FluentCartCustomerRights\AdminPage())->register();

        $app->router->group(function ($router) {
            require FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'app/Http/Routes/api.php';
        });
        
        \FluentCartCustomerRights\Shortcode::register();
    }

    public function initUpdater()
    {
        require_once FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_PATH . 'includes/PluginManager/Updater.php';

        $pluginFile = FLUENT_CART_CUSTOMER_RIGHTS_PLUGIN_FILE_PATH;

        new \FluentCartCustomerRights\PluginManager\Updater(
            'https://fluentcart.com/',
            $pluginFile,
            [
                'version'           => FLUENT_CART_CUSTOMER_RIGHTS_VERSION,
                'addon_slug'        => 'fluent-cart-customer-rights',
                'parent_product_id' => 21480,
                'plugin_title'      => 'FluentCart Customer Rights',
                'is_free'           => true,
            ]
        );

        add_filter('plugin_row_meta', function ($links, $pluginFilePath) use ($pluginFile) {
            if (plugin_basename($pluginFile) !== $pluginFilePath) {
                return $links;
            }

            $checkUpdateUrl = esc_url(admin_url('plugins.php?fluent-cart-customer-rights-check-update=' . time()));

            $links['check_update'] = '<a style="color: #583fad;font-weight: 600;" href="' . $checkUpdateUrl . '" aria-label="' . esc_attr__('Check Update', 'fluent-cart-customer-rights') . '">' . esc_html__('Check Update', 'fluent-cart-customer-rights') . '</a>';

            return $links;
        }, 10, 2);
    }

    public function handleDbMigration()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'fctcr_requests';
        $charsetCollate = $wpdb->get_charset_collate();

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) != $table) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `uuid` VARCHAR(64) NOT NULL,
                `order_id` BIGINT UNSIGNED NULL,
                `customer_id` BIGINT UNSIGNED NULL,
                `is_verified` TINYINT(1) NOT NULL DEFAULT 0,
                `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
                `name` VARCHAR(192) NOT NULL,
                `email` VARCHAR(192) NOT NULL,
                `order_reference` VARCHAR(192) NOT NULL,
                `message` TEXT NULL,
                `source` VARCHAR(20) NOT NULL DEFAULT 'public_form',
                `ip_address` VARCHAR(45) NULL,
                `submitted_at` DATETIME NULL,
                `processed_at` DATETIME NULL,
                `processed_by` BIGINT UNSIGNED NULL,
                `meta` LONGTEXT NULL,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
                PRIMARY KEY  (`id`),
                KEY idx_order_id (`order_id`),
                KEY idx_status (`status`)
            ) $charsetCollate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

            dbDelta($sql);
        }
    }
}

FluentCartCustomerRights::init();
