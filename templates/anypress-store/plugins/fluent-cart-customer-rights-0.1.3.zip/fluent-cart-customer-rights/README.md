# FluentCart Customer Rights

EU/German digital withdrawal function (**Widerrufsbutton**, § 356a BGB) add-on for [FluentCart](https://fluentcart.com) — legally required for German B2C online stores from **June 19, 2026** (EU Directive 2023/2673, Art. 11a Consumer Rights Directive).

Scaffolded from the `fluent-cart-page-history` addon structure (flat PHP, no build step).

## What it does

- Public 2-step withdrawal form via `[fluent_cart_withdrawal]` — statutory labels ("Vertrag widerrufen" → "Widerruf bestätigen"), name + order number + email identification, no login required
- Accepts **every** declaration: auto-matched orders become *verified* requests, unmatched ones land in an *unverified* queue for manual linking
- Timestamped acknowledgment email (declaration content + date and time of receipt) through FluentCart's email pipeline
- Admin: withdrawal widget on the single-order page (Accept/Decline + decision emails) and a Withdrawal Requests queue
- Customer profile: withdrawal entry point on orders and subscriptions

## Settings

FluentCart → Settings → Features & addon → **Withdrawal (EU)**:

| Setting | Default | Notes |
|---|---|---|
| Enable | off | Activating creates a draft "Withdraw from contract" page with the shortcode and stores its ID |
| Show in customer profile | on | Entry points on orders/subscriptions |
| Require verified order match | off | ⚠ Hard-rejecting unmatched declarations is a legal risk — keep off unless you know what you're doing |

The withdrawal page's intro text is edited directly on the created WP page; the flow texts ship with translatable statutory defaults.

## Data

Table: `{prefix}fctcr_requests` — one row per declaration (uuid, order link, verified flag, status `pending|accepted|declined`, name/email/reference/message, GMT `submitted_at`, processed by/at). Created on activation via `dbDelta`; retained on deactivation (legal record).

## Status

Work in progress — ticket board: `fluent-cart/dev-docs/withdrawal-button/kanban.md` (WDB-01 done: scaffold, settings module, page creation, DB table).

## License

GPL-2.0-or-later
